/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("containerLibrary.js")

function CAknSettingItemListQueryContainment() {
}

CAknSettingItemListQueryContainment.prototype.getAllowedAttribute = function() {
	return "is-setting-item-list-content";
}

setupAttributeBasedQueryContainment(CAknSettingItemListQueryContainment.prototype);

