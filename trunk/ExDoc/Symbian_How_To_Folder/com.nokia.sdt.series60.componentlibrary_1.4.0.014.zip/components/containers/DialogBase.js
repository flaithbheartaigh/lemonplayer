/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("containerLibrary.js")

function DialogBase() {
}

// IInitializer
DialogBase.prototype.initialize = function(instance) {
	if (isAvkonView(instance.parent)) {
		instance.properties.notifyEsc = true;
	} else {
		instance.properties.notifyEsc = false;
	}
}

