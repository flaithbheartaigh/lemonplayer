/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */
 
include("containerLibrary.js")

function CAknSettingItemListEventInfo() {
}

CAknSettingItemListEventInfo.prototype.getEventGroups = function(instance) {
	// do not provide CustomCCoeControl events
	return ["CCoeControl"];
		
}
