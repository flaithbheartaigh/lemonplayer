/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("containerLibrary.js")

function CAknDialogQueryContainment() {
}

function hasDialogContentAttribute(componentAttributes) {
	return hasAttributeValue(componentAttributes, "is-dialog-content", "true");
}

CAknDialogQueryContainment.prototype.canContainComponent = function(instance, otherComponent) {
	if (!hasDialogContentAttribute(otherComponent.attributes))
		return buildSimpleContainmentErrorStatus(
			lookupString("generalContainmentError"), 
			new Array( otherComponent.friendlyName ));
		
	return null;
}

CAknDialogQueryContainment.prototype.canContainChild = function(instance, child) {
	if (!hasDialogContentAttribute(child.component.attributes))
		return buildSimpleContainmentErrorStatus(
			lookupString("generalContainmentError"), 
			new Array( child.component.friendlyName ));
	
	return null;
}

CAknDialogQueryContainment.prototype.canRemoveChild = function(instance, child) {
	return true; // everything can be removed
}

CAknDialogQueryContainment.prototype.isValidComponentInPalette = function(instance, otherComponent) {
	return hasDialogContentAttribute(otherComponent.attributes);
}


