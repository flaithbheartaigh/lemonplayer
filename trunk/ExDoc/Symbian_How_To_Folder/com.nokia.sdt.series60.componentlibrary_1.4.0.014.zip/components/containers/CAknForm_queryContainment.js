/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("containerLibrary.js")

function CAknFormQueryContainment() {
}

CAknFormQueryContainment.prototype.getAllowedAttribute = function() {
	return "is-form-content";
}

setupAttributeBasedQueryContainment(CAknFormQueryContainment.prototype);

