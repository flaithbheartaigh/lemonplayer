/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

function CAknSettingItemListPropertyExtenders() {
}

	// Return instances that may provide extension properties
	// The target instance parameter is the instance to receive the
	// additional properties
CAknSettingItemListPropertyExtenders.prototype.getPropertyExtenders = function(instance, targetInstance) {
	if ((targetInstance.parent == instance) && 
		(targetInstance.attributes["is-layout-object"] == "true")) {
			return [instance];
	}
	return null;
}
	
CAknSettingItemListPropertyExtenders.prototype.getExtensionSetNames = function(instance, targetInstance) {
	return [ "default" ];
}

