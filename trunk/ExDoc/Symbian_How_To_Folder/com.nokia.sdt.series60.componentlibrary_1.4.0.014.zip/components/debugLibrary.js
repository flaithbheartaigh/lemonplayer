/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */


function trace(msg) {
	println(msg);
}

function traceRectangle(description, rect) {
	trace(description + ":" + rect);
}
