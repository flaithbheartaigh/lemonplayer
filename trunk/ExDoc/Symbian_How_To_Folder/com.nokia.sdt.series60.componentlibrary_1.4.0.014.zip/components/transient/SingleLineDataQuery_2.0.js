include("../implLibrary.js")

// IComponentValidator

function SingleLineDataQuery20Validator() {
}

SingleLineDataQuery20Validator.prototype.validate = function(instance, laf) {
	var messages = null;
	// in case the baseline sdk is changed from 2.1 and 2.0
	var properties = instance.properties;
	if (properties.type == null) {
		var message = createSimpleModelError(instance, 
			"type",
			lookupString("InvalidTypeError"),
			[ instance.name ] );
		messages = new java.util.ArrayList();
		messages.add(message);
	}
	return messages;
}

SingleLineDataQuery20Validator.prototype.queryPropertyChange = function(instance, propertyPath,
				newVal, laf) {
	// Only need to check at load time
	return null;
}

