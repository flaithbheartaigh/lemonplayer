/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("popupDialogLibrary.js")

function StandardNoteLayout() {
}

StandardNoteLayout.prototype.layout = function(instance, laf) {
	var properties = instance.properties;
	var flags = Font.ALIGN_LEFT;
	flags |= Font.WRAPPING_ENABLED;
			
	var iconRect = getIconRect(0, laf);
	var rect = calculateBounds(properties, laf, flags, iconRect.x, 0);

	properties.location.x = rect.x;
	properties.location.y = rect.y;
	properties.size.width = rect.width;
	properties.size.height = rect.height;
}

StandardNoteLayout.prototype.getPreferredSize = function(instance, laf, wHint, hHint) {
	return null;
}

StandardNoteLayout.prototype.propertyChanged = function(instance, property) {
	if (property == "text") {
		instance.forceLayout();
	}
}
