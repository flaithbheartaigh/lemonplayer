/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("../messageLibrary.js")
include("../implLibrary.js")

function MenuItemBase() {

}

// IComponentValidator
MenuItemBase.prototype.validate = function(instance) {

	var messages = null;
	
	// cannot have a "selected" event if a submenu is present
	if (instance.children.length != 0 && "selected" in instance.events) {
		var messages = new java.util.ArrayList();
		var modelMessage = newModelMessage(IStatus.WARNING, 
			formatString(
				lookupString("selectedEventInCascadingMenuItem"), 
				[ instance.name ]), 
			instance, null, "selected");
		messages.add(modelMessage);
	} 
	return messages;
}

MenuItemBase.prototype.queryPropertyChange = function(instance, propertyId, newValue) {
	return null;
}

