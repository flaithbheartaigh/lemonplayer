/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("../containers/containerLibrary.js")

function SystemMenuItem() {
}


// IQueryContainment

function canContainComponent(instance, component) {
	return buildSimpleContainmentErrorStatus(
			lookupString("systemMenuItemContainmentErr"), []);			
}

SystemMenuItem.prototype.canContainComponent = function(instance, otherComponent) {
	return canContainComponent(instance, otherComponent);
}

SystemMenuItem.prototype.canContainChild = function(instance, child) {
	return canContainComponent(instance, child.component);
}

SystemMenuItem.prototype.canRemoveChild = function(instance) {
	return false;
}

SystemMenuItem.prototype.isValidComponentInPalette = function(instance, otherComponent) {
	return false;
}

