/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("../containers/containerLibrary.js")

function CAknAppUiLayout() {
}

CAknAppUiLayout.prototype.layout = function(instance, laf) {
	doScreenLayout(instance, laf);
}

CAknAppUiLayout.prototype.getPreferredSize = function(instance, laf, wHint, hHint) {
	return null;
}

