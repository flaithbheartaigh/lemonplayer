include("../formLibrary.js")

function CAknAppUIpropertyExtender() {
}

// Return instances that may provide extension properties
// The target instance parameter is the instance to receive the
// additional properties
CAknAppUIpropertyExtender.prototype.getPropertyExtenders = function(instance, targetInstance) {
	for (var i in targetInstance.children) {
		
		if (isForm(targetInstance.children[i])) {
			return null;
		}
	}
	return [instance];
}
	
CAknAppUIpropertyExtender.prototype.getExtensionSetNames = function(instance, targetInstance) {
	if (instance == targetInstance && hasMSKSupport()){
			return [ "default" ];
	}
	return null;
}

function hasMSKSupport(){
	var version = getComponentVersions();
	if (version.getMajor() > 3 || (version.getMajor() == 3 && version.getMinor() >= 2)){
		return true;
	}
	
	return false;
}
