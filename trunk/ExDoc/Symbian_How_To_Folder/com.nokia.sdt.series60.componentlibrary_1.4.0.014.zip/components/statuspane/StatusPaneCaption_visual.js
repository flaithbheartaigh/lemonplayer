/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("../implLibrary.js")
include("../renderLibrary.js")
include("../srcgenLibrary.js")
include("titleLibrary.js")

function StatusPaneCaptionVisual() {
}

StatusPaneCaptionVisual.prototype.draw = function(instance, laf, graphics) {
	var properties = instance.properties;
	
	drawTitleText(instance, laf, graphics, properties.longCaption);
}

setupCommonDirectLabelEditing(StatusPaneCaptionVisual.prototype, "longCaption",
	null,	
	function(instance, laf) { return laf.getFont("titleFont"); 
	}
)
