/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("../implLibrary.js")
include("../renderLibrary.js")
include("../srcgenLibrary.js")

function StatusPaneContextBase() {
}

StatusPaneContextBase.prototype.draw = function(instance, laf, graphics) {
	var properties = instance.properties;
	
	if (laf.getBoolean("show.context.icon", true)) {
		graphics.setBackground(getBackgroundColor(instance, laf));

		// do not blend, since status pane has two different colors
		renderImage(StatusPaneContextBase.prototype, instance, laf, graphics, 
			0, 0, "image", false);
	}
	
}
