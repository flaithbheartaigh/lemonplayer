/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("../../embeddedControlImplLibrary.js");

function EditorBaseFormDirectImageEdit() {
}

setupCommonEmbeddedDirectImageEditing(EditorBaseFormDirectImageEdit.prototype);
setupEmbeddedImagePropertyInfo(EditorBaseFormDirectImageEdit.prototype);