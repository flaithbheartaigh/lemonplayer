/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

/*
	GlobalText does not obey the font or alignment settings, so do not expose them.
*/

function GlobalTextPropertyExtenders() {
}

	// Return instances that may provide extension properties
	// The target instance parameter is the instance to receive the
	// additional properties
GlobalTextPropertyExtenders.prototype.getPropertyExtenders = function(instance, targetInstance) {
	if (targetInstance == instance) {
		return [instance];
	}

	return null;
}
	
GlobalTextPropertyExtenders.prototype.getExtensionSetNames = function(instance, targetInstance) {
	return null;
}

