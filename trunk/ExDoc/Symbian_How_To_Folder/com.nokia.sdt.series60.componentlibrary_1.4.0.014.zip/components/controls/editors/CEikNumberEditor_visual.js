/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */


include("../../embeddedControlImplLibrary.js")
include("editorLibrary.js")

function CEikNumberEditorVisual() {
}

CEikNumberEditorVisual.prototype.getFlags = commonEditorGetFlags;

CEikNumberEditorVisual.prototype.getFont = function(instance, laf) {
	var fontName = instance.properties.font;
	return laf.getFont(fontName);
}

CEikNumberEditorVisual.prototype.getDisplayText = function(instance) {
	return instance.properties.number + "";
}

CEikNumberEditorVisual.prototype.getMaxLength = function(instance) {
	return 0;
}

setupEditorRendering(CEikNumberEditorVisual.prototype);

setupCommonEmbeddedDirectLabelEditing(CEikNumberEditorVisual.prototype,
	"number",
	null, // areafunction
	CEikNumberEditorVisual.prototype.getFont
);

setupCommonRangeCheckingValidation(CEikNumberEditorVisual.prototype, 
		lookupString("numberRC"), lookupString("numbersRC"),
		"minimum", "maximum", "number", null);
