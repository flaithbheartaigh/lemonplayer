/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */


include("../../formLibrary.js")
include("editorLibrary.js")


function CEikFloatingPointEditorVisual() {
}

CEikFloatingPointEditorVisual.prototype.getFlags = commonEditorGetFlags;

CEikFloatingPointEditorVisual.prototype.getFont = function(instance, laf) {
	return laf.getFont("NormalFont");
}

CEikFloatingPointEditorVisual.prototype.getDisplayText = function(instance) {
	return instance.properties.value + "";
}

CEikFloatingPointEditorVisual.prototype.getMaxLength = function(instance) {
	return instance.properties.maxlength;
}


setupEditorRendering(CEikFloatingPointEditorVisual.prototype);

setupCommonEmbeddedDirectLabelEditing(CEikFloatingPointEditorVisual.prototype,
	"value",
	null, // areafunction
	CEikFloatingPointEditorVisual.prototype.getFont
);

function unsetValueChecker() { }

function defaultValueChecker() { }

setupCommonRangeCheckingValidation(defaultValueChecker, 
			lookupString("value"), lookupString("values"),	// not default 
			"minimum", "maximum", "default", null);

function valueChecker() { }

setupCommonRangeCheckingValidation(valueChecker, 
		lookupString("value"), lookupString("values"),
		"minimum", "maximum", "value", null);
	
CEikFloatingPointEditorVisual.prototype.queryPropertyChange = function(instance, propertyPath,
					newValue, laf) {
	var message = defaultValueChecker.queryPropertyChange(instance, propertyPath, newValue, laf);
	if (message != null)
		return message;
	message = valueChecker.queryPropertyChange(instance, propertyPath, newValue, laf);
	if (message != null)
		return message;
	return null;
}

CEikFloatingPointEditorVisual.prototype.validate = function(instance, laf) {
	var message = defaultValueChecker.validate(instance, laf);
	if (message != null)
		return message;
	message = valueChecker.validate(instance, laf);
	if (message != null)
		return message;
	return null;
}

