var kYes = "Yes";
var kNo = "No";


function ChoiceListReconcile() {
}

ChoiceListReconcile.prototype.createDisplayValue = function(instance, propertyTypeName, propertyValue) {
	if (!propertyTypeName.equals("com.nokia.sdt.series60.ButtonData")) {
		return null;
	}
	
	if (propertyValue.showAsButtonValue == true){
		return kYes;
	}
	else {
		return kNo;
	}
}

ChoiceListReconcile.prototype.isDisplayValueEditable = function(instance, propertyTypeName) {
	if (!propertyTypeName.equals("com.nokia.sdt.series60.ButtonData")) {
		return true;
	}
	
	return true;
}
	
ChoiceListReconcile.prototype.applyDisplayValue = function(instance, propertyTypeName, displayValue, propertyValue) {
	if (!propertyTypeName.equals("com.nokia.sdt.series60.ButtonData")) {
		return;
	}
	
	if (displayValue == kYes){
		propertyValue.showAsButtonValue = true;
	} else { 
		propertyValue.showAsButtonValue = false;
	}
}
