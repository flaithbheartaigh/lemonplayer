/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */

include("../settingsListLibrary.js")

function CCoeControlBaseEventInfo() {
}

/** Only return a subset of events when a control is in a setting item list */
CCoeControlBaseEventInfo.prototype.getEventGroups = function(instance) {
	if (isSettingItemList(instance.parent))
		return ["SettingsList"];
	else if (instance.parent.attributes["is-transient-object"] == "true")
		return []; // no events
	else
		return ["CCoeControl"];
}

/** Only return a subset of events when a control is in a setting item list */
CCoeControlBaseEventInfo.prototype.getDefaultEventName = function(instance) {
	if (isSettingItemList(instance.parent))
		return "editingStopped";
	else
		return null;	// select component default
}
