The design_time folder is for design-time-only components, meaning
components that exist at design time but do not correspond to any run-time object.
