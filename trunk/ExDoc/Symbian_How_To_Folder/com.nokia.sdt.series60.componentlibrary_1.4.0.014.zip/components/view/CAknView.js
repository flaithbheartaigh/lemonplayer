include("../formLibrary.js")


function CAknViewPropertyExtenders() {
}

	// Return instances that may provide extension properties
	// The target instance parameter is the instance to receive the
	// additional properties
CAknViewPropertyExtenders.prototype.getPropertyExtenders = function(instance, targetInstance) {
	for (var i in targetInstance.children) {
		if (isForm(targetInstance.children[i])) {
			return null;
		}
	}

	return [instance];
}
	
CAknViewPropertyExtenders.prototype.getExtensionSetNames = function(instance, targetInstance) {
	if (instance == targetInstance)
		return [ "default" ];
		
	return null;
}

