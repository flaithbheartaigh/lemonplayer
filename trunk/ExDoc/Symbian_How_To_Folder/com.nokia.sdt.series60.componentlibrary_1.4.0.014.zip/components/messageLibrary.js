/*
 * Copyright (C) 2006 Nokia Corporation. All rights reserved.
 */


function buildSimpleErrorStatus(errorString, params) {
	statusBuilder = newStatusBuilder();
	statusBuilder.add(IStatus.ERROR, errorString, params);
	return statusBuilder.createStatus("", null);
}

function buildMultipleErrorStatus(header, errorString, params, status) {
	statusBuilder = newStatusBuilder();
	statusBuilder.add(status);
	statusBuilder.add(IStatus.ERROR, errorString, params);
	return statusBuilder.createStatus(header, null);
}

function buildSimpleWarningStatus(warningString, params) {
	statusBuilder = newStatusBuilder();
	statusBuilder.add(IStatus.WARNING, warningString, params);
	return statusBuilder.createStatus("", null);
}
