/*
============================================================================
 Name		: $(baseName)AppUi.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)AppUi implementation
============================================================================
*/

// INCLUDE FILES
#include <avkon.hrh>
#include <aknmessagequerydialog.h>
#include <aknnotewrappers.h>
#include <stringloader.h>
#include <f32file.h>
#include <s32file.h>

#include <$(baseName)_$(uid3).rsg>

#include "$(baseName).hrh"
#include "$(baseName).pan"
#include "$(baseName)Application.h"
#include "$(baseName)AppUi.h"
#include "$(baseName)AppView.h"

#include "Utils.h"
#include "MacroUtil.h"
#include "QueryDlgUtil.h"

#include "HelpView.h"
#include "LogoView.h"
// ============================ MEMBER FUNCTIONS ===============================


// -----------------------------------------------------------------------------
// C$(baseName)AppUi::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void C$(baseName)AppUi::ConstructL()
{
	// Initialise app UI with standard value.
	BaseConstructL(CAknAppUi::EAknEnableSkin);

	// Create view object
	iAppView = C$(baseName)AppView::NewL( );
	AddViewL( iAppView );
	
	iHelpView = CHelpView::NewL();
	AddViewL(iHelpView);
	iLogoView = CLogoView::NewL();
	AddViewL(iLogoView);
	
	SetDefaultViewL( *iAppView );
	
	//add your code here...

}
// -----------------------------------------------------------------------------
// C$(baseName)AppUi::C$(baseName)AppUi()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
C$(baseName)AppUi::C$(baseName)AppUi()
{
	// No implementation required
	iAppView=NULL;
}

// -----------------------------------------------------------------------------
// C$(baseName)AppUi::~C$(baseName)AppUi()
// Destructor.
// -----------------------------------------------------------------------------
//
C$(baseName)AppUi::~C$(baseName)AppUi()
{
	//add your code here...
	SAFE_DELETE(iDataModel)
	SAFE_DELETE(iUIMgr)
}

// -----------------------------------------------------------------------------
// C$(baseName)AppUi::HandleCommandL()
// Takes care of command handling.
// -----------------------------------------------------------------------------
//
void C$(baseName)AppUi::HandleCommandL( TInt aCommand )
{
	switch( aCommand )
	{
		case EEikCmdExit:
		case EAknSoftkeyExit:
			Exit();
			break;		
		case ECommandAbout:
			About();
			break;
		break;
		default:
			Panic( E$(baseName)Ui );
			break;
	}
}
// -----------------------------------------------------------------------------
//  Called by the framework when the application status pane
//  size is changed.  Passes the new client rectangle to the
//  AppView
// -----------------------------------------------------------------------------
//
void C$(baseName)AppUi::HandleStatusPaneSizeChange()
{
	if(iAppView!=NULL)
	iAppView->HandleStatusPaneSizeChange();
} 

void C$(baseName)AppUi::SHError(const TSHErrInfo& aInfo,const TSHErrState& aState)
{
	switch(aInfo) {
	default:
		break;
	}

	switch(aState) {
	case ESHErrSerious:
		Exit();
		break;
	default:
		break;
	}
}

void C$(baseName)AppUi::About()
	{
	TFileName filename;
	GetAppPath(filename);
	HBufC* textResource = StringLoader::LoadLC(R_ABOUT_FILE);
	filename.Append(textResource->Des());
	CleanupStack::PopAndDestroy(textResource);

	RFile file;
	TInt nErr = file.Open(CEikonEnv::Static()->FsSession(), filename, EFileRead
			| EFileShareAny);
	if (nErr != KErrNone)
		return;

	TFileText fileText;
	fileText.Set(file);
	TBuf<128> linePtr;
	HBufC* iText = NULL;

	while (fileText.Read(linePtr) == KErrNone)
		{
		if (iText!=NULL)
			{
			iText = iText->ReAllocL(iText->Length() + linePtr.Length() + 2);
			iText->Des().Append(linePtr);
			}
		else
			{
			iText = HBufC::NewL(linePtr.Length() + 2);
			iText->Des().Append(linePtr);
			}
		iText->Des().Append(CEditableText::ELineBreak);
		}
	file.Close();

	ShowModalAboutDlgL(R_ABOUT_DIALOG_TITLE,iText->Des());
	
	
	delete iText;
	}

// End of File
