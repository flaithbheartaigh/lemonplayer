/*
 * ============================================================================
 *  Name	 : CSettingExampleApplication from SettingExampleApplication.cpp
 *  Part of  : SettingExample
 *  Created  : by $(author)
 *  Copyright: $(copyright)
 * ============================================================================
 */
#include "SettingExampleDocument.h"
#include "SettingExampleApplication.h"

// local constants
static const TUid KUidSettingExampleApp = {$(uid3)}; 

CApaDocument* CSettingExampleApplication::CreateDocumentL()
	{  
	// Create an SettingExample document, and return a pointer to it
	CApaDocument* document = CSettingExampleDocument::NewL(*this);
	return document;
	}

TUid CSettingExampleApplication::AppDllUid() const
	{
	// Return the UID for the SettingExample application
	return KUidSettingExampleApp;
	}

