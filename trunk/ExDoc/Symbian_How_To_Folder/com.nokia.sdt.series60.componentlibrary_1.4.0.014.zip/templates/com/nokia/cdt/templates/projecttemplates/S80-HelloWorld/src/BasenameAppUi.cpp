/*
============================================================================
 Name		: $(baseName)AppUi.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)AppUi implementation
============================================================================
*/

#include <eikenv.h>
#include <ckninfo.h>
#include <hlplch.h>

#include "$(baseName).pan"
#include "$(baseName)Application.h"
#include "$(baseName)AppUi.h"
#include "$(baseName)AppView.h"
#include "$(baseName).hrh"
#include "$(baseName).hlp.hrh"

#include <$(baseName).rsg>


// ConstructL is called by the application framework
void C$(baseName)AppUi::ConstructL()
	{
	BaseConstructL();

	iAppView = C$(baseName)AppView::NewL(ClientRect());	

	AddToStackL(iAppView);
	}

C$(baseName)AppUi::C$(baseName)AppUi()							  
	{
	// no implementation required
	}

C$(baseName)AppUi::~C$(baseName)AppUi()
	{
	if (iAppView)
		{
		iEikonEnv->RemoveFromStack(iAppView);
		delete iAppView;
		iAppView = NULL;
		}
	}

// handle any menu commands
void C$(baseName)AppUi::HandleCommandL(TInt aCommand)
	{
	switch(aCommand)
		{
		case EEikCmdExit:
			CBaActiveScheduler::Exit();
			break;

		case E$(baseName)Command1:
			{
			_LIT(title,"Information");
			_LIT(message,"Hello world!");
			CCknInfoDialog::RunDlgLD(title, message);
			}
			break;
		case E$(baseName)CmdHelp:
			{
			CArrayFix<TCoeHelpContext>* buf = CCoeAppUi::AppHelpContextL();
			HlpLauncher::LaunchHelpApplicationL(iEikonEnv->WsSession(), buf);
			break;
			}
		case E$(baseName)CmdAbout:
			{
			CCknInfoDialog::RunDlgDefaultIconLD(R_ABOUT_DIALOG_TEXT, R_ABOUT_DIALOG_TITLE);
			break;
			}
			

		default:
			break;
		}
	}

CArrayFix<TCoeHelpContext>* C$(baseName)AppUi::HelpContextL() const
	{
	CArrayFixFlat<TCoeHelpContext>* array = new(ELeave)CArrayFixFlat<TCoeHelpContext>(1);
	CleanupStack::PushL(array);
	array->AppendL(TCoeHelpContext(KUid$(baseName)App, KGeneral_Information));
	CleanupStack::Pop(array);
	return array;
	}


