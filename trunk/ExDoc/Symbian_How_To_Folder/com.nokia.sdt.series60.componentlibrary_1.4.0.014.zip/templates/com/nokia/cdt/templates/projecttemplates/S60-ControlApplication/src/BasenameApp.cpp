/*
============================================================================
 Name		: $(baseName)App.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Main application class
============================================================================
*/

// INCLUDE FILES
#include	"$(baseName)App.h"
#include	"$(baseName)Document.h"

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// C$(baseName)App::AppDllUid()
// Returns application UID
// ---------------------------------------------------------
//
TUid C$(baseName)App::AppDllUid() const
	{
	return KUid$(baseName);
	}


// ---------------------------------------------------------
// C$(baseName)App::CreateDocumentL()
// Creates C$(baseName)Document object
// ---------------------------------------------------------
//
CApaDocument* C$(baseName)App::CreateDocumentL()
	{
	return C$(baseName)Document::NewL( *this );
	}

// ================= OTHER EXPORTED FUNCTIONS ==============
//
// ---------------------------------------------------------
// NewApplication() 
// Constructs C$(baseName)App
// Returns: created application object
// ---------------------------------------------------------
//
EXPORT_C CApaApplication* NewApplication()
	{
	return new C$(baseName)App;
	}

// ---------------------------------------------------------
// E32Dll(TDllReason) 
// Entry point function for EPOC Apps
// Returns: KErrNone: No error
// ---------------------------------------------------------
//
GLDEF_C TInt E32Dll( TDllReason )
	{
	return KErrNone;
	}



