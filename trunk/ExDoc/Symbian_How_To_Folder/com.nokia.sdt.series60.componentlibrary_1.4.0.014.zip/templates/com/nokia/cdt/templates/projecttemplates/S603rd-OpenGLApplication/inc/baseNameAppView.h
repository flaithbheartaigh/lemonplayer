/*
============================================================================
 Name		: $(baseName)AppView.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares view class for application.
============================================================================
*/

#ifndef __$(baseNameUpper)APPVIEW_h__
#define __$(baseNameUpper)APPVIEW_h__

// INCLUDES
#include <e32std.h>
#include <e32base.h>
#include <aknview.h>
#include <avkon.hrh>
#include <f32file.h>

#include "$(baseName)AppContainer.h"

// CLASS DECLARATION
class C$(baseName)AppView : public CAknView
{
public: // Constructors and destructor
	~C$(baseName)AppView();
	static C$(baseName)AppView* NewL();
	static C$(baseName)AppView* NewLC();
	
public:
	TUid Id() const;
	void HandleCommandL( TInt aCommand );
	void HandleStatusPaneSizeChange();
	
private:
	C$(baseName)AppView();
	void ConstructL();
	
protected:
	void DoActivateL(const TVwsViewId& aPrevViewId,	TUid aCustomMessageId,	const TDesC8& aCustomMessage );
	void DoDeactivate();
	
private:
	C$(baseName)AppContainer * iContainer;
};

#endif // __$(baseNameUpper)APPVIEW_h__

// End of File
