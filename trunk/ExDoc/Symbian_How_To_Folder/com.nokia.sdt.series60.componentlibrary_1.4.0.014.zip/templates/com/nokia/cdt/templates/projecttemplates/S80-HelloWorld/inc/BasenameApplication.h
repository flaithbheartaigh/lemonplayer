/*
============================================================================
 Name		: $(baseName)Application.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)Application header 
============================================================================
*/

#ifndef __$(baseNameUpper)_APPLICATION_H__
#define __$(baseNameUpper)_APPLICATION_H__

#include <eikapp.h>


// UID for the application, this should correspond to the uid defined in the mmp file
static const TUid KUid$(baseName)App = {$(uid3)};


/*! 
 @class C$(baseName)Application

 @discussion An instance of C$(baseName)Application is the application part of the Eikon
 application framework for the $(baseName) example application
 */
class C$(baseName)Application : public CEikApplication
	{
public:  // from CEikApplication

/*! 
 @function AppDllUid

 @discussion Return the application DLL UID value
 @result the UID of this Application/Dll
 */
	TUid AppDllUid() const;

protected: // from CEikApplication
/*! 
 @function CreateDocumentL

 @discussion Create a CApaDocument object and return a pointer to it
 @result a pointer to the created document
 */
	CApaDocument* CreateDocumentL();
	};

#endif // __$(baseNameUpper)_APPLICATION_H__
