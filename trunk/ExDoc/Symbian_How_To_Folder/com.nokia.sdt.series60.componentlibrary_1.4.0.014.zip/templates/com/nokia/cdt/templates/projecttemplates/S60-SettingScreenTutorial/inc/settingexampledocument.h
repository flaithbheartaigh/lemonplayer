/*
 * ============================================================================
 *  Name	 : CSettingExampleDocument from SettingExampleDocument.h
 *  Part of  : SettingExample
 *  Created  : by $(author)
 *  Copyright: $(copyright)
 * ============================================================================
 */

#ifndef __settingexample_DOCUMENT_H__
#define __settingexample_DOCUMENT_H__


#include <akndoc.h>

// Forward references
class CEikApplication;



/**
 * Class:		CSettingExampleDocument
 *
 * Discussion:	An instance of class CSettingExampleDocument is the Document 
 *				part of the AVKON application framework for the SettingExample 
 *				example application
 */
class CSettingExampleDocument : public CAknDocument
	{
public:

/**
 * Function:	NewL
 *
 * Discussion:  Construct a CSettingExampleDocument for the AVKON application 
 *				aApp using two phase construction, and return a pointer to 
 *				the created object
 *
 * Param:		aApp -  application creating this document
 *
 * Returns:		a pointer to the created instance of CSettingExampleDocument
 *
 */
	static CSettingExampleDocument* NewL(CEikApplication& aApp);

/**
 * Function:	NewLC
 *
 * Discussion:	Construct a CSettingExampleDocument for the AVKON application 
 *				aApp using two phase construction, and return a pointer to the 
 *				created object. Pointer to object is left on the cleanup stack
 *
 * Param:		aApp application creating this document
 *
 * Returns:		a pointer to the created instance of CSettingExampleDocument
 *
 */
	static CSettingExampleDocument* NewLC(CEikApplication& aApp);

/**
 * Function:	~CSettingExampleDocument
 *
 * Discussion:	 Destroy the object and release all memory objects
 *
 */
	~CSettingExampleDocument();

/**
 * Function:	CreateAppUiL
 *
 * Discussion:	Create a CSettingExampleAppUi object and return a pointer to it
 * Returns :	a pointer to the created instance of the AppUi created
 */
	CEikAppUi* CreateAppUiL();
private:

/**
 * Function:	ConstructL
 *
 * Discussion:	Perform the second phase construction of a CSettingExampleDocument object
 */
	void ConstructL();

/**
 * Function:	CSettingExampleDocument
 *
 * Discussion:	Perform the first phase of two phase construction
 *
 * Param:		aApp application creating this document
 */
	CSettingExampleDocument(CEikApplication& aApp);

	};


#endif // __settingexample_DOCUMENT_H__
