/*
 * ============================================================================
 *  Name	 : CSettingExampleAppUi from settingexampleui.cpp
 *  Part of  : SettingExample
 *  Created  : by $(author)
 *  Copyright: $(copyright)
 * ============================================================================
 */
#include "SettingExampleUi.h"
#include "SettingListView.h"
#include "ExampleSettingList.h"
#include "SettingsData.h"

// ConstructL is called by the application framework
void CSettingExampleAppUi::ConstructL()
	{
	BaseConstructL();

	// construct the data object the settings list will use
	iData = CSettingsData::NewL();

	// construct the view as well.
	CAknView* view;
	view = CSettingListView::NewLC(*iData);
	AddViewL(view);
	CleanupStack::Pop(view);
	ActivateLocalViewL(view->Id());
	}

CSettingExampleAppUi::CSettingExampleAppUi()							  
	{
	}

CSettingExampleAppUi::~CSettingExampleAppUi()
	{
	// make sure we clean up the data object
	delete iData;
	}

// handle menu commands
void CSettingExampleAppUi::HandleCommandL(TInt aCommand)
	{
	switch(aCommand)
		{
		case EAknSoftkeyExit:	// only softkey handled at this level
			Exit();
			break;
		default:
			break;
		}
	}


