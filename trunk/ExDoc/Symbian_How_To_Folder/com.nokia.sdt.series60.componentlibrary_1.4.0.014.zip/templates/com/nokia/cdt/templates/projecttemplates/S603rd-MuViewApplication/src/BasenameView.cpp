/*
============================================================================
 Name		: $(baseName)View.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)View implementation
============================================================================
*/

// INCLUDE FILES
#include  <aknviewappui.h>
#include  <avkon.hrh>
#include  <$(baseName).rsg>
#include  "$(baseName)View.h"
#include  "$(baseName)Container.h" 

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// C$(baseName)View::ConstructL(const TRect& aRect)
// EPOC two-phased constructor
// ---------------------------------------------------------
//
void C$(baseName)View::ConstructL()
	{
	BaseConstructL( R_VIEW1 );
	}

// ---------------------------------------------------------
// C$(baseName)View::~C$(baseName)View()
// destructor
// ---------------------------------------------------------
//
C$(baseName)View::~C$(baseName)View()
	{
	if ( iContainer )
		{
		AppUi()->RemoveFromViewStack( *this, iContainer );
		}

	delete iContainer;
	}

// ---------------------------------------------------------
// TUid C$(baseName)View::Id()
//
// ---------------------------------------------------------
//
TUid C$(baseName)View::Id() const
	{
	return KViewId;
	}

// ---------------------------------------------------------
// C$(baseName)View::HandleCommandL(TInt aCommand)
// takes care of view command handling
// ---------------------------------------------------------
//
void C$(baseName)View::HandleCommandL(TInt aCommand)
	{   
	switch ( aCommand )
		{
		case EAknSoftkeyOk:
			{
			iEikonEnv->InfoMsg( _L("view1 ok") );
			break;
			}
		case EAknSoftkeyBack:
			{
			AppUi()->HandleCommandL(EEikCmdExit);
			break;
			}
		default:
			{
			AppUi()->HandleCommandL( aCommand );
			break;
			}
		}
	}

// ---------------------------------------------------------
// C$(baseName)View::HandleViewRectChange()
// ---------------------------------------------------------
//
void C$(baseName)View::HandleViewRectChange()
	{
	if ( iContainer )
		{
		iContainer->SetRect( ClientRect() );
		}
	}

// ---------------------------------------------------------
// C$(baseName)View::DoActivateL(...)
// 
// ---------------------------------------------------------
//
void C$(baseName)View::DoActivateL(
	const TVwsViewId& /*aPrevViewId*/,TUid /*aCustomMessageId*/,
	const TDesC8& /*aCustomMessage*/)
	{
	if (!iContainer)
		{
		iContainer = new (ELeave) C$(baseName)Container;
		iContainer->SetMopParent(this);
		iContainer->ConstructL( ClientRect() );
		AppUi()->AddToStackL( *this, iContainer );
		} 
	}

// ---------------------------------------------------------
// C$(baseName)View::DoDeactivate()
// 
// ---------------------------------------------------------
//
void C$(baseName)View::DoDeactivate()
	{
	if ( iContainer )
		{
		AppUi()->RemoveFromViewStack( *this, iContainer );
		}
	
	delete iContainer;
	iContainer = NULL;
	}



