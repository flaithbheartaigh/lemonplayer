/*
============================================================================
 Name		: $(baseName)AppContainer.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Application view implementation
============================================================================
*/

// INCLUDE FILES
#include <coemain.h>
#include "$(baseName)AppContainer.h"

// ============================ MEMBER FUNCTIONS ===============================

// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
C$(baseName)AppContainer* C$(baseName)AppContainer::NewL( const TRect& aRect )
{
	C$(baseName)AppContainer* self = C$(baseName)AppContainer::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
}

// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
C$(baseName)AppContainer* C$(baseName)AppContainer::NewLC( const TRect& aRect )
{
	C$(baseName)AppContainer* self = new ( ELeave ) C$(baseName)AppContainer;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
}

// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void C$(baseName)AppContainer::ConstructL( const TRect& aRect )
{
	// Create a window for this application view
	CreateWindowL();
	SetRect( aRect );
	
	iEngine = C$(baseName)Engine::NewL(this,&Window());
	iEngine->SetRedererState();
	
	ActivateL();
	
	//add your code here ...
	iPeriodic = CPeriodic::NewL(CActive::EPriorityIdle); // Create an active object for
	// animating the scene
	iPeriodic->Start(100, 100, TCallBack(C$(baseName)AppContainer::DrawCallBack, this));
}

// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::C$(baseName)AppContainer()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
C$(baseName)AppContainer::C$(baseName)AppContainer()
{
	// No implementation required
}


// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::~C$(baseName)AppContainer()
// Destructor.
// -----------------------------------------------------------------------------
//
C$(baseName)AppContainer::~C$(baseName)AppContainer()
{
	// No implementation required
	delete iPeriodic;
	delete iEngine;	
}

// ---------------------------------------------------------
// C$(baseName)Container::CountComponentControls() const
// ---------------------------------------------------------
//
TInt C$(baseName)AppContainer::CountComponentControls() const
	{
	return 0; // return nbr of controls inside this container
	}

// ---------------------------------------------------------
// C$(baseName)Container::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* C$(baseName)AppContainer::ComponentControl(TInt aIndex) const
	{
	switch ( aIndex )
		{
		default:
			return NULL;
		}
	}

// ---------------------------------------------------------
// C$(baseName)Container::HandleControlEventL(
//	 CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void C$(baseName)AppContainer::HandleControlEventL(CCoeControl* /*aControl*/,TCoeEvent /*aEventType*/)
	{
	// TODO: Add your control event handler code here
	}
	
//------------------------------------------------------------------
//C$(baseName)AppContainer::OfferKeyEventL(
// const TKeyEvent& aKeyEvent,	TEventCode aType)
//-------------------------------------------------------------------
//
TKeyResponse C$(baseName)AppContainer::OfferKeyEventL(const TKeyEvent& aKeyEvent,	TEventCode aType)
	{
    // See if we have a selection
	if (iEngine)
		return iEngine->OfferKeyEventL(aKeyEvent,aType);
		
    TInt code = aKeyEvent.iCode;
    switch(code)
        {
		//add your code here...
		
        default:           
            break;
        }
	return EKeyWasNotConsumed;
	}
// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void C$(baseName)AppContainer::Draw( const TRect& /*aRect*/ ) const
{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();
	TRect drawRect( Rect());
	gc.Clear( drawRect );
	
	//add your code here...
	iEngine->Render();
}

// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void C$(baseName)AppContainer::SizeChanged()
{  
	DrawNow();
}

TInt C$(baseName)AppContainer::DrawCallBack(TAny* aInstance)
	{
	C$(baseName)AppContainer* instance = (C$(baseName)AppContainer*) aInstance;

	instance->DrawNow();

	return 0;
	}
// End of File
