
=== Introduction ===

This class template can help you create CAknView-based classes and the containers are also generated simultaneously. 

But, there are several todo items:
1) redefine view id in xxxView.h file.
2) define view rss: copy the rss code snippet into your project rss file in the end of xxxView.cpp file.
3) define or redefine the command id: ECmdAppTest


It is created by dougcn -- a Chinese guy!  (dougcn@gmail.com)

Hope you enjoy it!


=== Installation ===

The following installation steps are based on Carbide.c++ 1.2 Express Version:

1. Unzip Carbide.c++-Template-CAknView.zip into the following path: 

C:\Program Files\Nokia\Carbide.c++ v1.2\plugins\com.nokia.cdt.templates_1.2.0.29\templates\com\nokia\cdt\templates\

2. Remove the following folders from your Carbide installation folder, this will clear the cache files:

\configuration\org.eclipse.core.runtime
\configuration\org.eclipse.osgi


3. Startup your Carbide.c++ now!


That's all!
