/*
============================================================================
 Name		: $(baseName)AppUi.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)AppUi implementation
============================================================================
*/

// INCLUDE FILES
#include "$(baseName)App.h"
#include "$(baseName)Appui.h"
#include "$(baseName)View.h"
#include "$(baseName)View2.h"
#include <$(baseName).rsg>
#include "$(baseName).hrh"
#include "$(baseName).hlp.hrh"

#include <avkon.hrh>
#include <aknmessagequerydialog.h>
#include <aknglobalnote.h>
#include <hlplch.h>

// ================= MEMBER FUNCTIONS =======================
//
// ----------------------------------------------------------
// C$(baseName)AppUi::ConstructL()
// 
// ----------------------------------------------------------
//
void C$(baseName)AppUi::ConstructL()
	{
	BaseConstructL();


	// Show tabs for main views from resources
	CEikStatusPane* sp = StatusPane();

	// Fetch pointer to the default navi pane control
	iNaviPane = (CAknNavigationControlContainer*)sp->ControlL( 
		TUid::Uid(EEikStatusPaneUidNavi));

	// Tabgroup has been read from resource and it were pushed to the navi pane. 
	// Get pointer to the navigation decorator with the ResourceDecorator() function. 
	// Application owns the decorator and it has responsibility to delete the object.
	iDecoratedTabGroup = iNaviPane->ResourceDecorator();
	if (iDecoratedTabGroup)
		{
		iTabGroup = (CAknTabGroup*) iDecoratedTabGroup->DecoratedControl();
		iTabGroup->SetObserver( this );
		}

	C$(baseName)View* view1 = new (ELeave) C$(baseName)View;

	CleanupStack::PushL( view1 );
	view1->ConstructL();
	AddViewL( view1 );	  // transfer ownership to CAknViewAppUi
	CleanupStack::Pop();	// view1

	C$(baseName)View2* view2 = new (ELeave) C$(baseName)View2;

	CleanupStack::PushL( view2 );
	view2->ConstructL();
	AddViewL( view2 );	  // transfer ownership to CAknViewAppUi
	CleanupStack::Pop();	// view2

	SetDefaultViewL(*view1);

	}

// ----------------------------------------------------
// C$(baseName)AppUi::~C$(baseName)AppUi()
// Destructor
// Frees reserved resources
// ----------------------------------------------------
//
C$(baseName)AppUi::~C$(baseName)AppUi()
	{
	delete iDecoratedTabGroup;
	}

// ------------------------------------------------------------------------------
// C$(baseName)AppUi::DynInitMenuPaneL(TInt aResourceId,CEikMenuPane* aMenuPane)
//  This function is called by the EIKON framework just before it displays
//  a menu pane. Its default implementation is empty, and by overriding it,
//  the application can set the state of menu items dynamically according
//  to the state of application data.
// ------------------------------------------------------------------------------
//
void C$(baseName)AppUi::DynInitMenuPaneL(
	TInt /*aResourceId*/,CEikMenuPane* /*aMenuPane*/)
	{
	}

// ----------------------------------------------------
// C$(baseName)AppUi::HandleKeyEventL(
//	 const TKeyEvent& aKeyEvent,TEventCode /*aType*/)
// takes care of key event handling
// ----------------------------------------------------
//
TKeyResponse C$(baseName)AppUi::HandleKeyEventL(
	const TKeyEvent& aKeyEvent,TEventCode aType)
	{
	if ( iTabGroup == NULL )
		{
		return EKeyWasNotConsumed;
		}

	if ( aKeyEvent.iCode == EKeyLeftArrow || aKeyEvent.iCode == EKeyRightArrow )
		{
		return iTabGroup->OfferKeyEventL( aKeyEvent, aType );
		}
	else
		{
		return EKeyWasNotConsumed;
		}
	}

// ----------------------------------------------------
// C$(baseName)AppUi::HandleCommandL(TInt aCommand)
// takes care of command handling
// ----------------------------------------------------
//
void C$(baseName)AppUi::HandleCommandL(TInt aCommand)
	{
	switch ( aCommand )
		{
		case EAknSoftkeyExit:
		case EEikCmdExit:
			{
			Exit();
			break;
			}
		case E$(baseName)CmdAppTest:
			{
			CAknGlobalNote* globalNote = CAknGlobalNote::NewLC();
			HBufC* msg = iEikonEnv->AllocReadResourceLC(R_INFO_NOTE_TEXT);
			globalNote->ShowNoteL(EAknGlobalInformationNote, *msg);
			CleanupStack::PopAndDestroy(); //msg
			CleanupStack::PopAndDestroy(); //globalNote
			break;
			}
		case E$(baseName)CmdHelp:
			{
			CArrayFix<TCoeHelpContext>* buf = CCoeAppUi::AppHelpContextL();
			HlpLauncher::LaunchHelpApplicationL(iEikonEnv->WsSession(), buf);
			break;
			}
		case E$(baseName)CmdAbout:
			{
			CAknMessageQueryDialog* dlg = new (ELeave)CAknMessageQueryDialog(); 
			dlg->PrepareLC(R_ABOUT_QUERY_DIALOG);
			HBufC* title = iEikonEnv->AllocReadResourceLC(R_ABOUT_DIALOG_TITLE);
			dlg->QueryHeading()->SetTextL(*title);
			CleanupStack::PopAndDestroy(); //title
			HBufC* msg = iEikonEnv->AllocReadResourceLC(R_ABOUT_DIALOG_TEXT);
			dlg->SetMessageTextL(*msg);
			CleanupStack::PopAndDestroy(); //msg
			dlg->RunLD(); 
			break;
			}
			
		// TODO: Add Your command handling code here

		default:
			break;	  
		}
	}


// ----------------------------------------------------
// C$(baseName)AppUi::TabChangedL(TInt aIndex)
// This method gets called when CAknTabGroup active 
// tab has changed.
// ----------------------------------------------------
//
void C$(baseName)AppUi::TabChangedL(TInt aIndex)
	{
	ActivateLocalViewL(TUid::Uid(iTabGroup->TabIdFromIndex(aIndex)));
	}

CArrayFix<TCoeHelpContext>* C$(baseName)AppUi::HelpContextL() const
	{
	CArrayFixFlat<TCoeHelpContext>* array = new(ELeave)CArrayFixFlat<TCoeHelpContext>(1);
	CleanupStack::PushL(array);
	array->AppendL(TCoeHelpContext(KUid$(baseName), KGeneral_Information));
	CleanupStack::Pop(array);
	return array;
	}

