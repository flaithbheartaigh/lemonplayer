/*
============================================================================
 Name		: $(baseName)Document.h
 Author	 : $(author)
 Copyright : $(copyright)
 Description : Declares document class for application.
============================================================================
*/

#ifndef __$(baseNameUpper)_DOCUMENT_H__
#define __$(baseNameUpper)_DOCUMENT_H__


#include <eikdoc.h>

// Forward references
class C$(baseName)AppUi;
class CEikApplication;


/*! 
 @class C$(baseName)Document
 
 @discussion An instance of class C$(baseName)Document is the Document part of the Eikon
 application framework for the $(baseName) example application
 */
class C$(baseName)Document : public CEikDocument
	{
public:

/*!
 @function NewL
 
 @discussion Construct a C$(baseName)Document for the Eikon application aApp 
 using two phase construction, and return a pointer to the created object
 @param aApp application creating this document
 @result a pointer to the created instance of C$(baseName)Document
 */
	static C$(baseName)Document* NewL(CEikApplication& aApp);

/*!
 @function NewLC
 
 @discussion Construct a C$(baseName)Document for the Eikon application aApp 
 using two phase construction, and return a pointer to the created object
 @param aApp application creating this document
 @result a pointer to the created instance of C$(baseName)Document
 */
	static C$(baseName)Document* NewLC(CEikApplication& aApp);

/*!
 @function ~C$(baseName)Document
 
 @discussion Destroy the object and release all memory objects
 */
	~C$(baseName)Document();

public: // from CEikDocument
/*!
 @function CreateAppUiL 
 
 @discussion Create a C$(baseName)AppUi object and return a pointer to it
 @result a pointer to the created instance of the AppUi created
 */
	CEikAppUi* CreateAppUiL();

private:

/*!
 @function ConstructL
 
 @discussion Perform the second phase construction of a C$(baseName)Document object
 */
	void ConstructL();

/*!
 @function C$(baseName)Document
 
 @discussion Perform the first phase of two phase construction 
 @param aApp application creating this document
 */
	C$(baseName)Document(CEikApplication& aApp);

	};


#endif // __$(baseNameUpper)_DOCUMENT_H__
