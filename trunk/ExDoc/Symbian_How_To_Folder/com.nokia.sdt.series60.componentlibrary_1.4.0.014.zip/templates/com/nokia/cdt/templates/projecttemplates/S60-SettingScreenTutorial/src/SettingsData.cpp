#include "SettingsData.h"

// granularity for growing CheckBox list item array
// within CSettingsData object only.
const int KCheckBoxDataListGranularity = 3;


CSettingsData *CSettingsData::NewL()
	{
	CSettingsData *self = CSettingsData::NewLC();
	CleanupStack::Pop(self);
	return self;
	}

CSettingsData *CSettingsData::NewLC()
	{
	CSettingsData *self = new (ELeave) CSettingsData();
	CleanupStack::PushL(self);

	self->ConstructL();

	return self;
	}

CSettingsData::~CSettingsData()
	{
	// clear all elements out of the array
	iCheckboxArray.Reset();
	}

CSettingsData::CSettingsData() :
	iVolume(3),
	iCheckboxArray(KCheckBoxDataListGranularity)
	{
	// initialise local data
	iTime.HomeTime();
	iDate.HomeTime();
	}


void CSettingsData::ConstructL() 
{
	iCheckboxArray.AppendL(0);
	iCheckboxArray.AppendL(1);
	iCheckboxArray.AppendL(0);
}


///////////////////////////////////////////////////////////////////////////////
