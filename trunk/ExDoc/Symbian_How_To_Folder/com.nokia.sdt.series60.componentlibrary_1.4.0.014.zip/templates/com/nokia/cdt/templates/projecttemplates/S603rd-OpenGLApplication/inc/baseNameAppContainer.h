/*
============================================================================
 Name		: $(baseName)AppContainer.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares container class for application.
============================================================================
*/

#ifndef __$(baseNameUpper)APPCONTAINER_h__
#define __$(baseNameUpper)APPCONTAINER_h__

// INCLUDES
#include <coecntrl.h>
#include "$(baseName)Engine.h"
// CLASS DECLARATION
class C$(baseName)AppContainer : public CCoeControl, MCoeControlObserver
{
	public: // Constructors and destructor		
		~C$(baseName)AppContainer();		
		static C$(baseName)AppContainer* NewL( const TRect& aRect );
		static C$(baseName)AppContainer* NewLC( const TRect& aRect );
		
	public: // New functions

    public: // Functions from base classes
		TKeyResponse  OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);
		
	private: // Functions from base classes
		void SizeChanged();
		TInt CountComponentControls() const;
		CCoeControl* ComponentControl(TInt aIndex) const;
		void Draw(const TRect& aRect) const;
		void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);
		
		C$(baseName)AppContainer();
		void ConstructL(const TRect& aRect);
		
		static TInt DrawCallBack( TAny* aInstance );
		
	private: //data
		C$(baseName)Engine *iEngine;
		CPeriodic *iPeriodic;

};

#endif // __$(baseNameUpper)APPVIEW_h__

// End of File
