/*
============================================================================
 Name		: $(baseName)AppUi.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares UI class for application.
============================================================================
*/

#ifndef $(baseNameUpper)APPUI_H
#define $(baseNameUpper)APPUI_H

// INCLUDES
#include <aknappui.h>
#include <eikdialg.h>

// FORWARD DECLARATIONS
class C$(baseName)Dialog;


// CLASS DECLARATION

/**
* Application UI class.
* Provides support for the following features:
* - dialog architecture
* 
*/
class C$(baseName)AppUi : public CAknAppUi
	{
	public: // // Constructors and destructor

		/**
		* EPOC default constructor.
		*/	  
		void ConstructL();

		/**
		* Destructor.
		*/	  
		~C$(baseName)AppUi();
		
	public: // New functions

	public: // Functions from base classes

	private:
		// From MEikMenuObserver
		void DynInitMenuPaneL(TInt aResourceId,CEikMenuPane* aMenuPane);

	private:
		/**
		* From CEikAppUi, takes care of command handling.
		* @param aCommand command to be handled
		*/
		void HandleCommandL(TInt aCommand);

		/**
		* From CEikAppUi, handles key events.
		* @param aKeyEvent Event to handled.
		* @param aType Type of the key event. 
		* @return Response code (EKeyWasConsumed, EKeyWasNotConsumed). 
		*/
		virtual TKeyResponse HandleKeyEventL(
			const TKeyEvent& aKeyEvent,TEventCode aType);

		// From CCoeAppUi
	 	CArrayFix<TCoeHelpContext>* HelpContextL() const;

	private: //Data
		C$(baseName)Dialog* iAppDialog; 
	};

#endif


