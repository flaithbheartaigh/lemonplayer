/*
 * ============================================================================
 *  Name	 : CSettingExampleUi from SettingExampleUI.h
 *  Part of  : SettingExample
 *  Created  : by $(author)
 *  Copyright: $(copyright)
 * ============================================================================
 */

#ifndef __SettingExample_APPUI_H__
#define __SettingExample_APPUI_H__

#include <aknviewappui.h>
#include <aknnavi.h>

class CSettingsData;


/**
 * Class:		CSettingExampleAppUi
 *
 * Discussion:	An instance of class CSettingExampleAppUi is the UserInterface 
 *				part of the AVKON application framework for the SettingExample 
 *				example application
 *
 *
 */
class CSettingExampleAppUi : public CAknViewAppUi
	{
public:
	/**
	 * Function : ConstructL
	 *
	 * Discussion : Performs the second phase construction of a 
	 *				CSettingExampleAppUi object	this needs to be public due to 
	 *				the way the framework constructs the AppUi
	 */
	void ConstructL();

	/**
	 * Function :	CSettingExampleAppUi
	 *
	 * Discussion : Perform the first phase of two phase construction.
	 *				This needs to be public due to the way the framework 
	 *				constructs the AppUi
	 */
	CSettingExampleAppUi();

	/**
	 * Function :	~CSettingExampleAppUi
	 *
	 * Discussion :	Hidden virtual destructor. Destroys object and releases
	 *				all associated memory.
	 *				
	 */
	~CSettingExampleAppUi();


public: // from CEikAppUi
	/**
	 * Function : 
	 *
	 * Discussion :	Handle user menu selections
	 *				
	 * Params :		aCommand - the enumerated code for the option selected
	 *
	 * Returns : 
	 * 
	 */
	void HandleCommandL(TInt aCommand);

private:
	CSettingsData* iData;	/* Pointer to settings data - OWNED */
	};

#endif // __SettingExample_APPUI_H__

