/*
 ============================================================================
 Name		: $(classname).h
 Author	  : zengcity
 Version	 : 1.0
 Copyright   : Your copyright notice
 Description : C$(classname) declaration
 ============================================================================
 */

#ifndef $(classname$upper)_H
#define $(classname$upper)_H

// INCLUDES
#include <e32std.h>
#include <e32base.h>

#include <w32std.h>
#include <coecntrl.h>
#include <GLES\egl.h>

//LIBRARY        libgles_cm.lib ws32.lib imageconversion.lib fbscli.lib

// CLASS DECLARATION

/**
 *  C$(classname)
 * 
 */
class C$(classname) : public CBase
	{
public:
	// Constructors and destructor
	
	/**
	 * Destructor.
	 */
	~C$(classname)();

	/**
	 * Two-phased constructor.
	 */
	static C$(classname)* NewL(CCoeControl* aParentControl,RWindow*	aParentWindow);

	/**
	 * Two-phased constructor.
	 */
	static C$(classname)* NewLC(CCoeControl* aParentControl,RWindow*	aParentWindow);

private:

	/**
	 * Constructor for performing 1st stage construction
	 */
	C$(classname)(CCoeControl* aParentControl,RWindow*	aParentWindow);

	/**
	 * EPOC default constructor for performing 2nd stage construction
	 */
	void ConstructL();

	
public:
	void SetRedererState();
	void Render();
	
public:
	GLint iCameraDistance;
	GLint iFrame;
private:
	CCoeControl* iParentControl;
	RWindow*	iParentWindow;	
	
	EGLDisplay    iEglDisplay;         // display where the graphics are drawn
	EGLContext    iEglContext;         // rendering context
	EGLSurface    iEglSurface;         // window where the graphics are blitted

	TInt iScreenWidth;
	TInt iScreenHeight;
	
	};

#endif // $(classname)_H
