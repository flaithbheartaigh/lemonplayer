/*
============================================================================
 Name		: $(classname).h
 Author	  : $(author)
 Version	 : $(version)
 Copyright   : $(copyright)
 Description : C$(classname) declaration
============================================================================
*/

#ifndef $(classname$upper)_H
#define $(classname$upper)_H

// INCLUDES
#include <e32std.h>
#include <e32base.h>
#include <coecntrl.h>
#include <eikclb.h> 

// CLASS DECLARATION

/**
 *  C$(classname)
 * 
 */
class C$(classname) : public CCoeControl, MCoeControlObserver
	{
public:
	// Constructors and destructor

	/**
	 * Destructor.
	 */
	~C$(classname)();

	/**
	 * Two-phased constructor.
	 */
	static C$(classname)* NewL(const TRect& aRect);

	/**
	 * Two-phased constructor.
	 */
	static C$(classname)* NewLC(const TRect& aRect);

private:

	/**
	 * Constructor for performing 1st stage construction
	 */
	C$(classname)();

	/**
	 * EPOC default constructor for performing 2nd stage construction
	 */
	void ConstructL(const TRect& aRect);
	
public:
	// Functions from base classes
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);
	
private:
	// Functions from base classes
	void SizeChanged();
	TInt CountComponentControls() const;
	CCoeControl* ComponentControl(TInt aIndex) const;
	void Draw(const TRect& aRect) const;
	void HandleControlEventL(CCoeControl* aControl, TCoeEvent aEventType);
	
	void UpdateDisplay();
	void SetIconsL();		
	
private:
	//data
	CEikColumnListBox* iListBox;
	};

#endif // $(classname$upper)_H
