/*
============================================================================
 Name		: $(baseName)Container.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Container control implementation
============================================================================
*/

// INCLUDE FILES
#include "$(baseName)Container.h"

#include <eiklabel.h>  // for example label control


// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// C$(baseName)Container::ConstructL(const TRect& aRect)
// EPOC two phased constructor
// ---------------------------------------------------------
//
void C$(baseName)Container::ConstructL(const TRect& aRect)
	{
	CreateWindowL();


	SetRect(aRect);
	ActivateL();
	}

// Destructor
C$(baseName)Container::~C$(baseName)Container()
	{

	}

// ---------------------------------------------------------
// C$(baseName)Container::SizeChanged()
// Called by framework when the view size is changed
// ---------------------------------------------------------
//
void C$(baseName)Container::SizeChanged()
	{
	// TODO: Add here control resize code etc.

	}

// ---------------------------------------------------------
// C$(baseName)Container::CountComponentControls() const
// ---------------------------------------------------------
//
TInt C$(baseName)Container::CountComponentControls() const
	{
	return 0; // return nbr of controls inside this container
	}

// ---------------------------------------------------------
// C$(baseName)Container::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* C$(baseName)Container::ComponentControl(TInt aIndex) const
	{
	switch ( aIndex )
		{
		default:
			return NULL;
		}
	}

// ---------------------------------------------------------
// C$(baseName)Container::Draw(const TRect& aRect) const
// ---------------------------------------------------------
//
void C$(baseName)Container::Draw(const TRect& aRect) const
	{
	CWindowGc& gc = SystemGc();
	gc.Clear();
	// TODO: Add your drawing code here

	}

// ---------------------------------------------------------
// C$(baseName)Container::HandleControlEventL(
//	 CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void C$(baseName)Container::HandleControlEventL(
	CCoeControl* /*aControl*/,TCoeEvent /*aEventType*/)
	{
	// TODO: Add your control event handler code here
	}



