/*
 ============================================================================
 Name		: Particles.h
 Author	  : zengcity
 Version	 : 1.0
 Copyright   : Your copyright notice
 Description : CParticles declaration
 ============================================================================
 */

#ifndef $(baseNameUpper)ENGINE_H
#define $(baseNameUpper)ENGINE_H

// INCLUDES
#include <e32std.h>
#include <e32base.h>

#include <w32std.h>
#include <coecntrl.h>
#include <GLES\egl.h>
#include "Utils3d.h" // Utilities (texmanager, textures etc.)
#include "Glutils.h" // Misc GLU and GLUT functions

//LIBRARY        libgles_cm.lib ws32.lib imageconversion.lib fbscli.lib

// CLASS DECLARATION

/**
 *  CParticles
 * 
 */
class C$(baseName)Engine : public CFiniteStateMachine,public MTextureLoadingListener
	{
public:
	// Constructors and destructor
	enum
		{
		ELoadingTextures,
		ERunning
		};
	
	/**
	 * Destructor.
	 */
	~C$(baseName)Engine();

	/**
	 * Two-phased constructor.
	 */
	static C$(baseName)Engine
			* NewL(CCoeControl* aParentControl, RWindow* aParentWindow);

	/**
	 * Two-phased constructor.
	 */
	static C$(baseName)Engine* NewLC(CCoeControl* aParentControl,
			RWindow* aParentWindow);

private:

	/**
	 * Constructor for performing 1st stage construction
	 */
	C$(baseName)Engine(CCoeControl* aParentControl, RWindow* aParentWindow);

	/**
	 * EPOC default constructor for performing 2nd stage construction
	 */
	void ConstructL();

private:
	void OnStartLoadingTexturesL() ;
	void OnEndLoadingTexturesL() ;
	
public:
	TKeyResponse OfferKeyEventL(const TKeyEvent& aKeyEvent,TEventCode aType);
	
	void SetRedererState();
	void Render();

public:
	GLint iCameraDistance;
	GLint iFrame;
private:
	CCoeControl* iParentControl;
	RWindow* iParentWindow;

	EGLDisplay iEglDisplay; // display where the graphics are drawn
	EGLContext iEglContext; // rendering context
	EGLSurface iEglSurface; // window where the graphics are blitted

	TInt iScreenWidth;
	TInt iScreenHeight;
	
	CTextureManager * iTextureManager;
	TTexture iOpenGLES;

	};

#endif // $(baseNameUpper)ENGINE_H
