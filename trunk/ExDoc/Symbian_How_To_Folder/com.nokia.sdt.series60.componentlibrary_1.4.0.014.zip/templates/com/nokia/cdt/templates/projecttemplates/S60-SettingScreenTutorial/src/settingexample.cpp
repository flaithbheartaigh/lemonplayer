/*
 * ============================================================================
 *  Name	 : SettingExample.cpp
 *  Part of  : SettingExample
 *  Created  : by $(author)
 *  Copyright: $(copyright)
 * ============================================================================
 */

#include "SettingExampleApplication.h"

// DLL entry point, return that everything is ok
GLDEF_C TInt E32Dll(TDllReason /*aReason*/)
	{
	return KErrNone;
	}


// Create an application, and return a pointer to it
EXPORT_C CApaApplication* NewApplication()
	{
	return (new CSettingExampleApplication);
	}

