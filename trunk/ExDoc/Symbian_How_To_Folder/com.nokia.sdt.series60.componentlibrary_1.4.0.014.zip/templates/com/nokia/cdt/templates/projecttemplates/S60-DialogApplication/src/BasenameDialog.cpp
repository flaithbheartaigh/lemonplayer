/*
============================================================================
 Name		: $(baseName)Dialog.cpp
 Copyright   : $(copyright)
 Description : C$(baseName)Dialog implementation
============================================================================
*/

// INCLUDE FILES
#include	"$(baseName)Dialog.h"

#include <eiklabel.h>  // for example label control
#include <avkon.hrh>
#include <aknappui.h>

// ================= MEMBER FUNCTIONS =======================


// Destructor
C$(baseName)Dialog::~C$(baseName)Dialog()
	{
	}

// ---------------------------------------------------------
// C$(baseName)Dialog::OkToExitL(TInt aButtonId)
// called by framework when the softkey is pressed
// ---------------------------------------------------------
//
TBool C$(baseName)Dialog::OkToExitL(TInt aButtonId)
	{
	// Translate the button presses into commands for the appui & current
	// view to handle
	if ( aButtonId == EAknSoftkeyOptions )
		{
		iAvkonAppUi->ProcessCommandL( EAknSoftkeyOptions );
		}
	else if ( aButtonId == EAknSoftkeyExit )
		{
		iAvkonAppUi->ProcessCommandL( EEikCmdExit );
		}
	
	return EFalse;
	}

// ---------------------------------------------------------
// C$(baseName)Dialog::PreLayoutDynInitL();
// called by framework before dialog is shown 
// ---------------------------------------------------------
//
void C$(baseName)Dialog::PreLayoutDynInitL()
	{
	}




