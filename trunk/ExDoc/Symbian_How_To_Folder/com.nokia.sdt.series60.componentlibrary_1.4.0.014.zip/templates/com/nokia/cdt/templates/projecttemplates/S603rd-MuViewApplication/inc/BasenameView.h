/*
============================================================================
 Name		: $(baseName)View.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares view class for application.
============================================================================
*/

#ifndef $(baseNameUpper)VIEW_H
#define $(baseNameUpper)VIEW_H

// INCLUDES
#include <aknview.h>


// CONSTANTS
// UID of view
const TUid KViewId = {1};

// FORWARD DECLARATIONS
class C$(baseName)Container;

// CLASS DECLARATION

/**
*  C$(baseName)View view class.
* 
*/
class C$(baseName)View : public CAknView
	{
	public: // Constructors and destructor

		/**
		* EPOC default constructor.
		*/
		void ConstructL();

		/**
		* Destructor.
		*/
		~C$(baseName)View();

	public: // Functions from base classes
		
		/**
		* From CAknView returns Uid of View
		* @return TUid uid of the view
		*/
		TUid Id() const;

		/**
		* From MEikMenuObserver delegate commands from the menu
		* @param aCommand a command emitted by the menu 
		* @return void
		*/
		void HandleCommandL(TInt aCommand);

		/**
		* From CAknView reaction if size change
		* @return void
		*/
		void HandleViewRectChange();

	private:

		/**
		* From CAknView activate the view
		* @param aPrevViewId 
		* @param aCustomMessageId 
		* @param aCustomMessage 
		* @return void
		*/
		void DoActivateL(const TVwsViewId& aPrevViewId,TUid aCustomMessageId,
			const TDesC8& aCustomMessage);

		/**
		* From CAknView deactivate the view (free resources)
		* @return void
		*/
		void DoDeactivate();

	private: // Data
		C$(baseName)Container* iContainer;
	};

#endif


