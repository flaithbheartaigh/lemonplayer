/*
============================================================================
 Name		: $(baseName)AppView.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Application view implementation
============================================================================
*/

#include <cknenv.h>

#include <$(baseName).rsg>

#include "$(baseName)AppView.h"

// Standard construction sequence
C$(baseName)AppView* C$(baseName)AppView::NewL(const TRect& aRect)
	{
	C$(baseName)AppView* self = C$(baseName)AppView::NewLC(aRect);
	CleanupStack::Pop(self);
	return self;
	}

C$(baseName)AppView* C$(baseName)AppView::NewLC(const TRect& aRect)
	{
	C$(baseName)AppView* self = new (ELeave) C$(baseName)AppView;
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

C$(baseName)AppView::C$(baseName)AppView()
	{
	// no implementation required
	}

C$(baseName)AppView::~C$(baseName)AppView()
	{
	// no implementation required
	}

void C$(baseName)AppView::ConstructL(const TRect& aRect)
	{
	// Create a window for this application view
	CreateWindowL();

	// Set the windows size
	SetRect(aRect);

	// Indicate that the control is blank
	SetBlank();

	// Set the control's border
	SetBorder(TGulBorder::EFlatContainer);

	// Set the correct application view (Note: ESkinAppViewWithCbaNoToolband is the default)
	CknEnv::Skin().SetAppViewType(ESkinAppViewWithCbaNoToolband);

	// Activate the window, which makes it ready to be drawn
	ActivateL();
	}

// Draw this application's view to the screen
void C$(baseName)AppView::Draw(const TRect& aRect) const
	{
	// Draw the parent control
	CEikBorderedControl::Draw(aRect);

	// Get the standard graphics context 
	CWindowGc& gc = SystemGc();
	
	// Gets the control's extent - Don't encroach on the border
	TRect rect = Border().InnerRect(Rect());

	// Ensure that the border is not overwritten by future drawing operations
	gc.SetClippingRect(rect);
	}


