/*
============================================================================
 Name		: $(baseName)Document.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares document class for application.
============================================================================
*/

#ifndef $(baseNameUpper)DOCUMENT_H
#define $(baseNameUpper)DOCUMENT_H

// INCLUDES
#include <akndoc.h>

// CONSTANTS

// FORWARD DECLARATIONS
class  CEikAppUi;

// CLASS DECLARATION

/**
*  C$(baseName)Document application class.
*/
class C$(baseName)Document : public CAknDocument
	{
	public: // Constructors and destructor
		/**
		* Two-phased constructor.
		*/
		static C$(baseName)Document* NewL(CEikApplication& aApp);

		/**
		* Destructor.
		*/
		virtual ~C$(baseName)Document();

	public: // New functions

	public: // Functions from base classes
	protected:  // New functions

	protected:  // Functions from base classes

	private:

		/**
		* EPOC default constructor.
		*/
		C$(baseName)Document(CEikApplication& aApp);
		void ConstructL();

	private:

		/**
		* From CEikDocument, create C$(baseName)AppUi "App UI" object.
		*/
		CEikAppUi* CreateAppUiL();
	};

#endif



