/*
============================================================================
 Name		: $(baseName)Application.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)Application header 
============================================================================
*/

#ifndef __$(baseNameUpper)_APPLICATION_H__
#define __$(baseNameUpper)_APPLICATION_H__

#include <eikapp.h>

// UID for the application, this should correspond to the uid defined in the mmp file
static const TUid KUid$(baseName)App = {$(uid3)};


class C$(baseName)Application : public CEikApplication
	{
	public:  // from CEikApplication
		TUid AppDllUid() const;

	protected: // from CEikApplication
		CApaDocument* CreateDocumentL();

	};

#endif // __$(baseNameUpper)_APPLICATION_H__
