/*
============================================================================
 Name		: $(baseName)AppUi.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares UI class for application.
============================================================================
*/

#ifndef __$(baseNameUpper)_APPUI_H__
#define __$(baseNameUpper)_APPUI_H__

#include <eikappui.h>

// Forward reference
class C$(baseName)AppView;

/*! 
 @class C$(baseName)AppUi

 @discussion An instance of class C$(baseName)AppUi is the UserInterface part of the Eikon
 application framework for the $(baseName) example application
 */
class C$(baseName)AppUi : public CEikAppUi
	{
public:
/*!
 @function ConstructL

 @discussion Perform the second phase construction of a C$(baseName)AppUi object
 this needs to be public due to the way the framework constructs the AppUi 
 */
	void ConstructL();

/*!
 @function C$(baseName)AppUi

 @discussion Perform the first phase of two phase construction.
 This needs to be public due to the way the framework constructs the AppUi 
 */
	C$(baseName)AppUi();


/*!
 @function ~C$(baseName)AppUi

 @discussion Destroy the object and release all memory objects
 */
	~C$(baseName)AppUi();


public: // from CEikAppUi
/*!
 @function HandleCommandL

 @discussion Handle user menu selections
 @param aCommand the enumerated code for the option selected
 */
	void HandleCommandL(TInt aCommand);

	// From CCoeAppUi
 	CArrayFix<TCoeHelpContext>* HelpContextL() const;

private:
/*! @var iAppView The application view */
	C$(baseName)AppView* iAppView;
	};


#endif // __$(baseNameUpper)_APPUI_H__

