/*
============================================================================
 Name		: $(baseName)Document.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares document class for application.
============================================================================
*/

#ifndef __$(baseNameUpper)_DOCUMENT_H__
#define __$(baseNameUpper)_DOCUMENT_H__


#include <eikdoc.h>

// Forward references
class C$(baseName)AppUi;
class CEikApplication;


class C$(baseName)Document : public CEikDocument
	{
	public:
		static C$(baseName)Document* NewL(CEikApplication& aApp);
		static C$(baseName)Document* NewLC(CEikApplication& aApp);
		~C$(baseName)Document();

	public: // from CEikDocument
		CEikAppUi* CreateAppUiL();

	private:
		void ConstructL();
		C$(baseName)Document(CEikApplication& aApp);

	};

#endif // __$(baseNameUpper)_DOCUMENT_H__
