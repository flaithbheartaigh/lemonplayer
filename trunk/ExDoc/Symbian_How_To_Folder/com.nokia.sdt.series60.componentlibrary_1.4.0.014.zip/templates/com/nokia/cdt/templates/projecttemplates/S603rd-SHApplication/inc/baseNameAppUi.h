/*
============================================================================
 Name		: $(baseName)AppUi.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares UI class for application.
============================================================================
*/

#ifndef __$(baseNameUpper)APPUI_h__
#define __$(baseNameUpper)APPUI_h__

// INCLUDES
#include <aknappui.h>
#include <aknviewappui.h>

#include "SHModel.h"
#include "UIManager.h"
#include "SHError.h"

// FORWARD DECLARATIONS
class C$(baseName)AppView;

class CHelpView;
class CLogoView;

// CLASS DECLARATION
/**
* C$(baseName)AppUi application UI class.
* Interacts with the user through the UI and request message processing
* from the handler class
*/
class C$(baseName)AppUi : public CAknViewAppUi
	{
	public: // Constructors and destructor
		void ConstructL();
		C$(baseName)AppUi();
		virtual ~C$(baseName)AppUi();

	private:  // Functions from base classes
		void HandleCommandL( TInt aCommand );
		void HandleStatusPaneSizeChange();

	public:
		CSHModel* GetModel() {return iDataModel;};
		CUIManager* GetUI() {return iUIMgr;};
		void SHError(const TSHErrInfo& aInfo,const TSHErrState& aState);
	
	private:
		void About();
	
	private: // Data
		C$(baseName)AppView* iAppView;		
		
		CHelpView* iHelpView;
		CLogoView* iLogoView;
		
		CSHModel* iDataModel;
		CUIManager* iUIMgr;
		
	};

#endif // __$(baseNameUpper)APPUI_h__

// End of File
