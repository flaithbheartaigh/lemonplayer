/*
============================================================================
 Name		: $(baseName)AppUi.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)AppUi implementation
============================================================================
*/

#include <eikenv.h>
#include <ckninfo.h>
#include <eikrted.h>
#include <txtrich.h>
#include <ckntitle.h>
#include <eiktbar.h>
#include <eikaufty.h>
#include <eikspane.h>
#include <eikdoc.h>
#include <ckninfo.h>
#include <hlplch.h>

#include "$(baseName).pan"
#include "$(baseName)Application.h"
#include "$(baseName)AppUi.h"
#include "$(baseName)Document.h"
#include "$(baseName).hrh"
#include "$(baseName).hlp.hrh"

#include <$(baseName).rsg>

const TInt KDefaultTextGranularity=256;

// ConstructL is called by the application framework
void C$(baseName)AppUi::ConstructL()
	{
	BaseConstructL();

	iEditor = new (ELeave) CEikRichTextEditor();

	iRichText = CRichText::NewL( CEikonEnv::Static()->SystemParaFormatLayerL(), CEikonEnv::Static()->SystemCharFormatLayerL(),
							CEditableText::ESegmentedStorage, KDefaultTextGranularity);


	const TInt flags=EEikEdwinOwnsWindow|EEikEdwinKeepDocument|EEikEdwinInclusiveSizeFixed|EEikEdwinUserSuppliedText|
						EEikEdwinNoAutoSelection|EEikEdwinAlwaysShowSelection;

	iEditor->ConstructL(NULL,0,0, flags);
	iEditor->CreateScrollBarFrameL();
	iEditor->ScrollBarFrame()->SetScrollBarVisibilityL(CEikScrollBarFrame::EOff, CEikScrollBarFrame::EAuto);
	iEditor->SetAdjacent(EGulAdjLeft | EGulAdjRight | EGulAdjTop | EGulAdjBottom);

	TRect clientRect=ClientRect();	
	
	iEditor->SetDocumentContentL( *iRichText, CEikEdwin::EUseText );

	iEditor->SetRect(clientRect);
	iEditor->ActivateL();
	iEditor->SetFocus(ETrue);
	iEditor->SetAllowBorders(ETrue);
	}

C$(baseName)AppUi::C$(baseName)AppUi()							  
	{
	// no implementation required
	}

C$(baseName)AppUi::~C$(baseName)AppUi()
	{
	delete iEditor;
	iEditor = NULL;
	delete iRichText;
	iRichText = NULL;
	}

// Changes normal view to full screen or vice versa. 
void C$(baseName)AppUi::ChangeFullScreenL()
	{
	MEikAppUiFactory* factory = iEikonEnv->AppUiFactory(); 
	CEikButtonGroupContainer* bar = factory->ToolBar();			// CBA
	CEikToolBar* band = factory->ToolBand();					// Title
	CEikToolBar* titleband = factory->TitleBand();				// This is not used
	CEikStatusPane* pane = factory->StatusPane();				// left hand status pane
	CCknAppTitle* title	= static_cast<CCknAppTitle*>( band->ControlById(E$(baseName)AppTitle) ); // title control

	TInt titleBarAdjacent	= EGulAdjNone;

	if ( titleband )
		{
		titleband->MakeVisible(EFalse);
		}

	bar->SetComponentsToInheritVisibility(ETrue);
	bar->MakeVisible(!bar->IsVisible());
	band->SetComponentsToInheritVisibility(ETrue);


	if ( pane )
		{
		pane->MakeVisible(!pane->IsVisible());
		}

	band->MakeVisible(!band->IsVisible());

	TRect clientRect = ClientRect();

	TRect bandRect	= band->Rect();
	bandRect.iTl.iX	= clientRect.iTl.iX;
	bandRect.iBr.iX	= clientRect.iBr.iX;
	bandRect.iBr.iY	= bandRect.iTl.iY + title->MinimumSize().iHeight;
	band->SetRect(bandRect);
	title->SetRect(band->Rect());

	band->SetAdjacent(titleBarAdjacent);
	band->DrawDeferred();
	bar->DrawDeferred();
	title->DrawDeferred();
	iEditor->SetRect(clientRect);
	iEditor->ForceScrollBarUpdateL();
	iEditor->DrawDeferred();
	}	


TKeyResponse C$(baseName)AppUi::HandleKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType)
	{
	return iEditor->OfferKeyEventL(aKeyEvent, aType);
	}


// handle any menu commands
void C$(baseName)AppUi::HandleCommandL(TInt aCommand)
	{
	switch(aCommand)
		{
		case EEikCmdExit:
			{
			CBaActiveScheduler::Exit();
			}
			break;

		case E$(baseName)Copy:
			{
			iEditor->ClipboardL(CEikEdwin::ECopy);
			}
			break;
		case E$(baseName)Cut:
			{
			iEditor->ClipboardL( CEikEdwin::ECut );
			}
			break;
		case E$(baseName)Paste:
			{
			iEditor->ClipboardL( CEikEdwin::EPaste );
			}
			break;
		case E$(baseName)FullScreen:
			{
			ChangeFullScreenL();
			}
			break;
		case E$(baseName)SelectAll:
			{
			iEditor->SelectAllL();
			}
			break;
		case E$(baseName)Open:
			{
			// TODO: 
			// Implement open functionality here
			}
			break;
		case E$(baseName)Save:
			{
			// TODO: 
			// Implement document saving here
			// NOTE: Document should have application UID in content.
			}
			break;
		case E$(baseName)CmdHelp:
			{
			CArrayFix<TCoeHelpContext>* buf = CCoeAppUi::AppHelpContextL();
			HlpLauncher::LaunchHelpApplicationL(iEikonEnv->WsSession(), buf);
			break;
			}
		case E$(baseName)CmdAbout:
			{
			CCknInfoDialog::RunDlgDefaultIconLD(R_ABOUT_DIALOG_TEXT, R_ABOUT_DIALOG_TITLE);
			break;
			}
			
		default:
			{
			Panic(E$(baseName)Ui);
			break;
			}
		}
	}


TBool C$(baseName)AppUi::ProcessCommandParametersL( TApaCommand /*aCommand*/, TFileName& /*aDocumentName*/, const TDesC8& /*aTail*/)
	{
	// TODO: Implement ProcessCommandParametersL function to enable processing shell commands.
	return EFalse;
	}

CArrayFix<TCoeHelpContext>* C$(baseName)AppUi::HelpContextL() const
	{
	CArrayFixFlat<TCoeHelpContext>* array = new(ELeave)CArrayFixFlat<TCoeHelpContext>(1);
	CleanupStack::PushL(array);
	array->AppendL(TCoeHelpContext(KUid$(baseName)App, KGeneral_Information));
	CleanupStack::Pop(array);
	return array;
	}
