/*
============================================================================
 Name		: $(baseName)Document.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)Document implementation
============================================================================
*/

#include <txtrich.h>
#include <eikenv.h>   // CEikEnv
#include <cknenv.h>   // CknEnv

#include "$(baseName)AppUi.h"
#include "$(baseName)Document.h"

// Standard Symbian OS construction sequence
C$(baseName)Document* C$(baseName)Document::NewL(CEikApplication& aApp)
	{
	C$(baseName)Document* self = NewLC(aApp);
	CleanupStack::Pop(self);
	return self;
	}

C$(baseName)Document* C$(baseName)Document::NewLC(CEikApplication& aApp)
	{
	C$(baseName)Document* self = new (ELeave) C$(baseName)Document(aApp);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

void C$(baseName)Document::ConstructL()
	{
	}	

C$(baseName)Document::C$(baseName)Document(CEikApplication& aApp) : CEikDocument(aApp) 
	{
	// no implementation required
	}

C$(baseName)Document::~C$(baseName)Document()
	{
	}

CEikAppUi* C$(baseName)Document::CreateAppUiL()
	{
	// Create the application user interface, and return a pointer to it,
	// the framework takes ownership of this object
	CEikAppUi* appUi = new (ELeave) C$(baseName)AppUi;
	return appUi;
	}
