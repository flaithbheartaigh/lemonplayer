/*
 * ============================================================================
 *  Name	 : CSettingExampleApplication from SettingExampleApplication.h
 *  Part of  : SettingExample
 *  Created  : by $(author)
 *  Copyright: $(copyright)
 * ============================================================================
 */

#ifndef __settingexample_APPLICATION_H__
#define __settingexample_APPLICATION_H__

#include <aknapp.h>

/**
 * Class:		CSettingExampleApplication
 *
 * Discussion:	An instance of CSettingExampleApplication is the application 
 *				part of the AVKON application framework for the SettingExample 
 *				example application
 */
class CSettingExampleApplication : public CAknApplication
	{
public:  // from CApaApplication

/**
 * Function:	AppDllUid
 *
 * Discussion:	Returns the application DLL UID value
 *
 * Returns:		the UID of this Application/Dll
 *
 */
	TUid AppDllUid() const;

protected: // from CEikApplication
/**
 * Function:	CreateDocumentL
 *
 * Discussion:	Create a CApaDocument object and return a pointer to it
 *
 * Returns:		a pointer to the created document
 *
 */
	CApaDocument* CreateDocumentL();
	};

#endif // __settingexample_APPLICATION_H__
