/*
============================================================================
 Name		: $(baseName)Document.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)Document implementation
============================================================================
*/

// INCLUDE FILES
#include "$(baseName)Document.h"
#include "$(baseName)Appui.h"

// ================= MEMBER FUNCTIONS =======================

// constructor
C$(baseName)Document::C$(baseName)Document(CEikApplication& aApp)
: CAknDocument(aApp)
	{
	}

// destructor
C$(baseName)Document::~C$(baseName)Document()
	{
	}

// EPOC default constructor can leave.
void C$(baseName)Document::ConstructL()
	{
	}

// Two-phased constructor.
C$(baseName)Document* C$(baseName)Document::NewL(
		CEikApplication& aApp)	 // C$(baseName)App reference
	{
	C$(baseName)Document* self = new (ELeave) C$(baseName)Document( aApp );
	CleanupStack::PushL( self );
	self->ConstructL();
	CleanupStack::Pop();

	return self;
	}

// ----------------------------------------------------
// C$(baseName)Document::CreateAppUiL()
// constructs C$(baseName)AppUi
// ----------------------------------------------------
//
CEikAppUi* C$(baseName)Document::CreateAppUiL()
	{
	return new (ELeave) C$(baseName)AppUi;
	}


