/*
 ============================================================================
 Name		: Particles.cpp
 Author	  : zengcity
 Version	 : 1.0
 Copyright   : Your copyright notice
 Description : CParticles implementation
 ============================================================================
 */

#include "$(baseName)Engine.h"

// MACROS
#define FRUSTUM_LEFT   -1.f     //left vertical clipping plane
#define FRUSTUM_RIGHT   1.f     //right vertical clipping plane
#define FRUSTUM_BOTTOM -1.f     //bottom horizontal clipping plane
#define FRUSTUM_TOP     1.f     //top horizontal clipping plane
#define FRUSTUM_NEAR    3.f     //near depth clipping plane
#define FRUSTUM_FAR  1000.f     //far depth clipping plane
#define tex(u,v) (GLbyte)( (u) - 128 ) , (GLbyte)( (v) - 128 )

C$(baseName)Engine::C$(baseName)Engine(CCoeControl* aParentControl, RWindow* aParentWindow) :
	iParentControl(aParentControl), iParentWindow(aParentWindow), iFrame(0)
	{
	iCameraDistance = -8;
	iScreenWidth = aParentControl->Rect().Width();
	iScreenHeight = aParentControl->Rect().Height();
	// No implementation required
	}

C$(baseName)Engine::~C$(baseName)Engine()
	{
	delete iTextureManager;

	eglMakeCurrent(iEglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
	eglDestroySurface(iEglDisplay, iEglSurface);
	eglDestroyContext(iEglDisplay, iEglContext);
	eglTerminate(iEglDisplay); // release resources associated with EGL & OpenGL ES
	}

C$(baseName)Engine* C$(baseName)Engine::NewLC(CCoeControl* aParentControl,
		RWindow* aParentWindow)
	{
	C$(baseName)Engine* self = new (ELeave) C$(baseName)Engine(aParentControl, aParentWindow);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

C$(baseName)Engine* C$(baseName)Engine::NewL(CCoeControl* aParentControl,
		RWindow* aParentWindow)
	{
	C$(baseName)Engine* self = C$(baseName)Engine::NewLC(aParentControl, aParentWindow);
	CleanupStack::Pop(); // self;
	return self;
	}

void C$(baseName)Engine::ConstructL()
	{
	EGLConfig config; // config describing properties of EGLSurface
	EGLConfig *configList = NULL; // pointer for EGLConfigs
	int configSize = 0; // num of configs we want EGL to return
	int numOfConfigs = 0; // num of configs actually returned

	/* Get the display for drawing graphics */
	iEglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);

	/* Initialize display */
	eglInitialize(iEglDisplay, NULL, NULL);

	/* Get the number of all possible EGLConfigs */
	eglGetConfigs(iEglDisplay, configList, configSize, &numOfConfigs);
	configSize = numOfConfigs;

	/* Allocate memory for configList */
	configList = (EGLConfig*) User::Alloc(sizeof(EGLConfig) * configSize);

	/* Define properties for the wanted EGLSurface.
	 To get the best possible performance, choose
	 an EGLConfig with a buffersize matching
	 the current window's display mode*/
	TDisplayMode DMode = iParentWindow->DisplayMode();
	TInt BufferSize = 0;

	switch (DMode)
		{
		case (EColor4K):
			BufferSize = 12;
			break;
		case (EColor64K):
			BufferSize = 16;
			break;
		case (EColor16M):
			BufferSize = 24;
			break;
		case (EColor16MU):
			BufferSize = 32;
			break;
		default:
			_LIT(KDModeError, "unsupported displaymode");
			User::Panic(KDModeError, 0);
			break;
		}

	const EGLint attrib_list[] =
		{
		EGL_BUFFER_SIZE, BufferSize, EGL_DEPTH_SIZE, 16, EGL_NONE
	};

	/* Choose those configs that fulfill the requirement in attrib_list */
	eglChooseConfig(iEglDisplay, attrib_list, configList, configSize,
			&numOfConfigs);

	/* Choose the ��best�� config and use that in the future */
	config = configList[0]; // Choose the best EGLConfig. EGLConfigs
	// returned by eglChooseConfig are sorted so
	// that the best matching EGLconfig is first in
	// the list.	 

	User::Free(configList); // free configList, not used anymore

	/* Create a surface where the graphics are blitted */
	iEglSurface = eglCreateWindowSurface(iEglDisplay, config, iParentWindow,
			NULL);

	/* Create a rendering context */
	iEglContext = eglCreateContext(iEglDisplay, config, NULL, NULL);

	/* Make the context current. Binds to the current rendering thread and surface. Use the same surface for both drawing and reading */
	eglMakeCurrent(iEglDisplay, iEglSurface, iEglSurface, iEglContext);

	iTextureManager = CTextureManager::NewL(iScreenWidth, iScreenHeight,
			FRUSTUM_TOP, FRUSTUM_BOTTOM, FRUSTUM_RIGHT, FRUSTUM_LEFT,
			FRUSTUM_NEAR, this);
	iTextureManager->SetScreenSize(iScreenWidth, iScreenHeight);
	}

/** Vertice coordinates for the cube. */
static const GLbyte vertices[24 * 3] =
{
    /* top */
    -1,  1,  1,
    1,  1,  1,
    1, -1,  1,
    -1, -1,  1,

    /* front */
    1,  1,  1,
    1,  1, -1,
    1, -1, -1,
    1, -1,  1,

    /* right */
    -1,  1,  1,
    -1,  1, -1,
    1,  1, -1,
    1,  1,  1,

    /* left */
    1, -1,  1,
    1, -1, -1,
    -1, -1, -1,
    -1, -1,  1,

    /* back */
    -1, -1,  1,
    -1, -1, -1,
    -1,  1, -1,
    -1,  1,  1,

    /* bottom */
    -1,  1, -1,
    1,  1, -1,
    1, -1, -1,
    -1, -1, -1
};

/** Colors for vertices (Red, Green, Blue, Alpha). */
//static const GLubyte colors[8 * 4] =
//	{
//	0, 255, 0, 255, 0, 0, 255, 255, 0, 255, 0, 255, 255, 0, 0, 255,
//
//	0, 0, 255, 255, 255, 0, 0, 255, 0, 0, 255, 255, 0, 255, 0, 255
//	};
static GLfloat colors[12][3] = // �ʺ���ɫ
			{
				{
				1.0f, 0.5f, 0.5f
				},
				{
				1.0f, 0.75f, 0.5f
				},
				{
				1.0f, 1.0f, 0.5f
				},
				{
				0.75f, 1.0f, 0.5f
				},
				{
				0.5f, 1.0f, 0.5f
				},
				{
				0.5f, 1.0f, 0.75f
				},
				{
				0.5f, 1.0f, 1.0f
				},
				{
				0.5f, 0.75f, 1.0f
				},
				{
				0.5f, 0.5f, 1.0f
				},
				{
				0.75f, 0.5f, 1.0f
				},
				{
				1.0f, 0.5f, 1.0f
				},
				{
				1.0f, 0.5f, 0.75f
				}
			};

/**
 * Indices for drawing the triangles.
 * The color of the triangle is determined by
 * the color of the last vertex of the triangle.
 */
static const GLubyte triangles[10 * 3] =
{
    /* top */
     1,0,3,
     1,3,2,

     /* front */
     5,4,7,
     5,7,6,

     /* right */
     9,8,11,
     9,11,10,

     /* left */
     13,12,15,
     13,15,14,

     /* back */
     17,16,19,
     17,19,18
};

static const GLbyte nokTexCoords[24 * 2] =
	{
	/* top, whole texture nasa_hubble.h */
	tex(0,0),
    tex(255,0), 
    tex(255,255), 
    tex(0,255), 

    /* front, spiral with tail */
    tex(0,255), 
    tex(127,255), 
    tex(127,127), 
    tex(0,127), 

    /* right, red nebulae */
    tex(127,255), 
    tex(255,255), 
    tex(255,127), 
    tex(127,127), 

    /* left, plasma cloud */
    tex(0,127), 
    tex(127,127), 
    tex(127,0), 
    tex(0,0), 

    /* back, 2 spirals */
    tex(127,127), 
    tex(255,127), 
    tex(255,0), 
    tex(127,0), 

    /* bottom, whole texture ogles.jpg */
    tex(255,255), 
    tex(255,0), 
    tex(0,0), 
    tex	(0,255)
	};

void C$(baseName)Engine::SetRedererState()
	{
	// Reinitialize viewport and projection.
	glViewport(0, 0, iScreenWidth, iScreenHeight);

	// Recalculate the view frustrum
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	GLfloat aspectRatio = (GLfloat) (iScreenWidth) / (GLfloat) (iScreenHeight);
	glFrustumf(FRUSTUM_LEFT * aspectRatio, FRUSTUM_RIGHT * aspectRatio,
			FRUSTUM_BOTTOM, FRUSTUM_TOP,
			FRUSTUM_NEAR, FRUSTUM_FAR );
	glMatrixMode(GL_MODELVIEW);

	// Set the screen background color.
	glClearColor(0.f, 0.f, 0.f, 1.f);

	// Enable back face culling.
	glEnable(GL_CULL_FACE);
	glEnable(GL_TEXTURE_2D);

	// Enable vertex arrays.
	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);

	glMatrixMode(GL_TEXTURE);
	glLoadIdentity();
	glScalef(1.0f / 255.0f, 1.0f / 255.0f, 1.0f);
	glTranslatef(128.0f, 128.0f, 0.0f);

	glMatrixMode(GL_MODELVIEW);

	// Set array pointers.
	glVertexPointer(3, GL_BYTE, 0, vertices);
	glTexCoordPointer(2, GL_BYTE, 0, nokTexCoords);

	// Enable color arrays.
	//glEnableClientState(GL_COLOR_ARRAY);

	// Set color pointers.
	//glColorPointer(4, GL_UNSIGNED_BYTE, 0, colors);

	// Set the initial shading mode
	glShadeModel(GL_FLAT);
	//	glShadeModel(GL_SMOOTH);

	glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_FASTEST);
	//	glBlendFunc(GL_ONE, GL_ONE );
	_LIT(KOGLESTexture, "OpenGL.bmp");
	iTextureManager->RequestToLoad(KOGLESTexture, &iOpenGLES);
	iTextureManager->DoLoadL();

	}

void C$(baseName)Engine::Render()
	{
	glClear(GL_COLOR_BUFFER_BIT);

	glLoadIdentity();
	glTranslatex(0, 0, iCameraDistance << 16);
	glRotatex(iFrame << 16, 1 << 16, 0, 0);
	glRotatex(iFrame << 15, 0, 1 << 16, 0);
	glRotatex(iFrame << 14, 0, 0, 1 << 16);
	
	iFrame++;
	
//	glColor4f(colors[0][0],colors[0][1],colors[0][2],0.5f);
	glBindTexture(  GL_TEXTURE_2D, iOpenGLES.iID );
	glDrawElements( GL_TRIANGLES, 10 * 3, GL_UNSIGNED_BYTE, triangles );

	eglSwapBuffers(iEglDisplay, iEglSurface);

	}

void C$(baseName)Engine::OnStartLoadingTexturesL()
	{
	SetStateL(ELoadingTextures);
	}

void C$(baseName)Engine::OnEndLoadingTexturesL()
	{
	if (GetState() == ELoadingTextures)
		{
		SetStateL(ERunning);
		}
	}

TKeyResponse C$(baseName)Engine::OfferKeyEventL(const TKeyEvent& aKeyEvent,
		TEventCode aType)
	{
	switch (aType)
		{
		case EEventKey:
			switch (aKeyEvent.iCode)
				{
				case EKeyUpArrow://ok
					iCameraDistance-=5;
					break;
				case EKeyDownArrow:
					iCameraDistance+=5;
					break;
				}
			break;
		}
	return EKeyWasNotConsumed;
	}
