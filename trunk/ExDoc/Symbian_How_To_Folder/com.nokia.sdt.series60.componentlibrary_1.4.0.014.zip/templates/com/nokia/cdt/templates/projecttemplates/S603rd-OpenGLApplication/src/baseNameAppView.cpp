/*
============================================================================
 Name		: $(baseName)AppView.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Application view implementation
============================================================================
*/

// INCLUDE FILES
#include <aknviewappui.h>

#include "$(baseName)AppView.h"

#include <$(baseName)_$(uid3).rsg>
#include "$(baseName).hrh"

// ============================ MEMBER FUNCTIONS ===============================
C$(baseName)AppView::C$(baseName)AppView()
{
	// No implementation required
	iContainer=NULL;
}


C$(baseName)AppView::~C$(baseName)AppView()
{
	DoDeactivate();
}

C$(baseName)AppView* C$(baseName)AppView::NewLC()
{
	C$(baseName)AppView* self = new (ELeave)C$(baseName)AppView();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

C$(baseName)AppView* C$(baseName)AppView::NewL()
{
	C$(baseName)AppView* self=C$(baseName)AppView::NewLC();
	CleanupStack::Pop(); // self;
	return self;
}

void C$(baseName)AppView::ConstructL()
{
	BaseConstructL( R_VIEW_APP );
	
	//add your code here...
	
}
/**
 * 
 * */
TUid C$(baseName)AppView::Id() const
{
	return TUid::Uid( E$(baseName)AppViewId );
}
void C$(baseName)AppView::HandleCommandL( TInt aCommand )
{
	switch ( aCommand )
	{
		default:
			AppUi()->HandleCommandL(aCommand);
	}
}
void C$(baseName)AppView::HandleStatusPaneSizeChange()
{
	if(iContainer!=NULL)
		iContainer->SetRect( ClientRect() );
}

/**
 * 
 * */
void C$(baseName)AppView::DoActivateL(const TVwsViewId& aPrevViewId,	TUid aCustomMessageId,	const TDesC8& aCustomMessage )
{
	if( iContainer==NULL) {
		iContainer = C$(baseName)AppContainer::NewL( ClientRect() );
		iContainer->SetMopParent(this);
		AppUi()->AddToStackL( *this, iContainer );
	
		//add your init code ...
		
	}	
}
void C$(baseName)AppView::DoDeactivate()
{
	if ( iContainer!=NULL ){
		AppUi()->RemoveFromViewStack( *this, iContainer );
		delete iContainer;
		iContainer = NULL;
	}
}
// End of File
