/*
============================================================================
 Name		: $(baseName)Dialog.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares dialog class for application.
============================================================================
*/

#ifndef $(baseNameUpper)DIALOG_H
#define $(baseNameUpper)DIALOG_H

// INCLUDES
#include <eikdialg.h>

// FORWARD DECLARATIONS

// CLASS DECLARATION

/**
* C$(baseName)Dialog dialog class
* 
*/
class C$(baseName)Dialog : public CEikDialog
	{
	public: // Constructors and destructor
		/**
		* Destructor.
		*/
		~C$(baseName)Dialog();

	public: // New functions

	public: // Functions from base classes

	protected:  // New functions

	protected:  // Functions from base classes
		/**
		 * From CEikDialog : This is called in CEikDialog::ExecuteLD()
		 *				   before a form is drawn.
		 */
		void PreLayoutDynInitL();

		/**
		* From CEikDialog : This is called by the dialog framework, returns true if the 
		* dialog can exit, false otherwise.
		*
		* @param aButtonId  Id of the softkey which was pressed
		* @return		   ETrue if the dialog can exit, false otherwise.
		*/
		TBool OkToExitL( TInt aButtonId );


	private: //data
	};

#endif


