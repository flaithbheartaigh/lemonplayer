/*
============================================================================
 Name		: $(baseName)AppUi.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares UI class for application.
============================================================================
*/

#ifndef __$(baseNameUpper)_APPUI_H__
#define __$(baseNameUpper)_APPUI_H__

#include <eikappui.h>

// Forward reference
class C$(baseName)AppView;
class CEikRichTextEditor;

class C$(baseName)AppUi : public CEikAppUi
	{
	public:
		void ConstructL();
		C$(baseName)AppUi();
		~C$(baseName)AppUi();

	public: // from CEikAppUi
		void HandleCommandL(TInt aCommand);
		TKeyResponse HandleKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);
		TBool ProcessCommandParametersL(TApaCommand aCommand, TFileName& aDocumentName, const TDesC8& aTail);

		// From CCoeAppUi
	 	CArrayFix<TCoeHelpContext>* HelpContextL() const;

	private: 
		void ChangeFullScreenL();

	private:
		CEikRichTextEditor* iEditor;
		CRichText* iRichText;
	};

#endif // __$(baseNameUpper)_APPUI_H__

