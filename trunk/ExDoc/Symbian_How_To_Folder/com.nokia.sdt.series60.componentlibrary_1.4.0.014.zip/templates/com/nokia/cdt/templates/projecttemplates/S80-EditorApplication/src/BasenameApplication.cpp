/*
============================================================================
 Name		: $(baseName)Application.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)Application implementation
============================================================================
*/

#include "$(baseName)Document.h"
#include "$(baseName)Application.h"


CApaDocument* C$(baseName)Application::CreateDocumentL()
	{  
	// Create an $(baseName) document, and return a pointer to it
	CApaDocument* document = C$(baseName)Document::NewL(*this);
	return document;
	}

TUid C$(baseName)Application::AppDllUid() const
	{
	// Return the UID for the $(baseName) application
	return KUid$(baseName)App;
	}

