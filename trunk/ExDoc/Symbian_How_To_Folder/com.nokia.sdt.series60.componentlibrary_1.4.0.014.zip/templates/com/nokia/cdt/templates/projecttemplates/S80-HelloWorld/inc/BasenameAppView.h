/*
============================================================================
 Name		: $(baseName)AppView.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Application view declaration
============================================================================
*/

#ifndef __$(baseNameUpper)_APPVIEW_H__
#define __$(baseNameUpper)_APPVIEW_H__


#include <eikbctrl.h>

/*! 
 @class C$(baseName)AppView
 
 @discussion An instance of the Application View object for the $(baseName) 
 example application
 */
class C$(baseName)AppView : public CEikBorderedControl
	{
public:

/*!
 @function NewL

 @discussion Create a C$(baseName)AppView object, which will draw itself to aRect
 @param aRect the rectangle this view will be drawn to
 @result a pointer to the created instance of C$(baseName)AppView
 */
	static C$(baseName)AppView* NewL(const TRect& aRect);

/*!
 @function NewLC

 @discussion Create a C$(baseName)AppView object, which will draw itself to aRect
 @param aRect the rectangle this view will be drawn to
 @result a pointer to the created instance of C$(baseName)AppView
 */
	static C$(baseName)AppView* NewLC(const TRect& aRect);


/*!
 @function ~C$(baseName)AppView
 
 @discussion Destroy the object and release all memory objects
 */
	 ~C$(baseName)AppView();


public:  // from CEikBorderedControl
/*!
 @function Draw
 
 @discussion Draw this C$(baseName)AppView to the screen
 @param aRect the rectangle of this view that needs updating
 */
	void Draw(const TRect& aRect) const;
 

private:

/*!
 @function ConstructL
 
 @discussion  Perform the second phase construction of a C$(baseName)AppView object
 @param aRect the rectangle this view will be drawn to
 */
	void ConstructL(const TRect& aRect);

/*!
 @function C$(baseName)AppView
 
 @discussion Perform the first phase of two phase construction 
 */
	C$(baseName)AppView();
	};


#endif // __$(baseNameUpper)_APPVIEW_H__
