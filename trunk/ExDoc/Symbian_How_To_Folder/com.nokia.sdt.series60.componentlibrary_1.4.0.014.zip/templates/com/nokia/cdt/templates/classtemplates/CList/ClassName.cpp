/*
============================================================================
 Name		: $(classname).cpp
 Author	  : $(author)
 Version	 : $(version)
 Copyright   : $(copyright)
 Description : C$(classname) implementation
============================================================================
*/
#include "$(classname).h"

#include <coemain.h>
#include <apgtask.h>
#include <eikenv.h>
#include <apgcli.h>
#include <aknlists.h> 
#include <AknIconArray.h> 
#include <eikclbd.h>
#include <.rsg>

C$(classname)::C$(classname)()
	{
	// No implementation required
	}

C$(classname)::~C$(classname)()
	{
	if (iListBox)
		delete iListBox;
	}

C$(classname)* C$(classname)::NewLC(const TRect& aRect)
	{
	C$(classname)* self = new (ELeave) C$(classname)();
	CleanupStack::PushL(self);
	self->ConstructL(aRect);
	return self;
	}

C$(classname)* C$(classname)::NewL(const TRect& aRect)
	{
	C$(classname)* self = C$(classname)::NewLC(aRect);
	CleanupStack::Pop(); // self;
	return self;
	}

void C$(classname)::ConstructL(const TRect& aRect)
	{
	CreateWindowL();

	iListBox = new (ELeave) CAknSingleGraphicStyleListBox();
	iListBox->ConstructL(this);
	iListBox->SetContainerWindowL(*this);

	// Creates scrollbar.
	iListBox->CreateScrollBarFrameL(ETrue);
	iListBox->ScrollBarFrame()->SetScrollBarVisibilityL(
			CEikScrollBarFrame::EOff, CEikScrollBarFrame::EAuto);

	SetIconsL();
	UpdateDisplay();

	SetRect(aRect);
	ActivateL();
	}

// ---------------------------------------------------------
// CThemeChangeContainer::CountComponentControls() const
// ---------------------------------------------------------
//
TInt C$(classname)::CountComponentControls() const
	{
	TInt count(0);
	if (iListBox)
		count++;

	return count; // return nbr of controls inside this container
	}

// ---------------------------------------------------------
// CThemeChangeContainer::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* C$(classname)::ComponentControl(TInt aIndex) const
	{
	switch (aIndex)
		{
		case 0:
			return iListBox; // Returns the pointer to listbox object.
		default:
			return NULL;
		}
	}

// ---------------------------------------------------------
// CThemeChangeContainer::HandleControlEventL(
//	 CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void C$(classname)::HandleControlEventL(CCoeControl* /*aControl*/,
		TCoeEvent /*aEventType*/)
	{
	// TODO: Add your control event handler code here
	}

//------------------------------------------------------------------
//C$(classname)::OfferKeyEventL(
// const TKeyEvent& aKeyEvent,	TEventCode aType)
//-------------------------------------------------------------------
//
TKeyResponse C$(classname)::OfferKeyEventL(
		const TKeyEvent& aKeyEvent, TEventCode aType)
	{
	// See if we have a selection
	TInt code = aKeyEvent.iCode;
	switch (code)
		{
		//add your code here...
		case EKeyDownArrow:
		case EKeyUpArrow:
			return iListBox->OfferKeyEventL(aKeyEvent, aType);
		default:
			break;
		}
	return EKeyWasNotConsumed;
	}
// -----------------------------------------------------------------------------
// C$(classname)::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void C$(classname)::Draw(const TRect& /*aRect*/) const
	{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();
	TRect drawRect(Rect());
	gc.Clear(drawRect);

	//add your code here...
	}

// -----------------------------------------------------------------------------
// C$(classname)::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void C$(classname)::SizeChanged()
	{
	if (iListBox)
		{
		iListBox->SetRect(Rect());
		}
	DrawNow();
	}

/*

#include <avkon.mbg>
#include <avkonicons.hrh>

RESOURCE AKN_ICON_ARRAY r_icon_mark
    {
    type = EAknIconArraySimple;
    bmpfile = AVKON_ICON_FILE;
    icons =
        {
        AKN_ICON
            {
            iconId = EMbmAvkonQgn_prop_radiobutt_on;
            maskId = EMbmAvkonQgn_prop_radiobutt_on_mask;
            },
        AKN_ICON
            {
            iconId = EMbmAvkonQgn_prop_radiobutt_off;
            maskId = EMbmAvkonQgn_prop_radiobutt_off_mask;
            },
        AKN_ICON
            {
            iconId = EMbmAvkonQgn_prop_mmc_memc_large;
            maskId = EMbmAvkonQgn_prop_mmc_memc_large_mask;
            }            
        };
    }
 */
void C$(classname)::SetIconsL()
	{
	CAknIconArray* icons = new (ELeave) CAknIconArray(2);
	CleanupStack::PushL(icons);
	icons->ConstructFromResourceL(R_ICON_MARK);
	iListBox->ItemDrawer()->ColumnData()->SetIconArray(icons);
	CleanupStack::Pop(); // icons
	}

void C$(classname)::UpdateDisplay()
	{

	CTextListBoxModel* model = iListBox->Model();
	CDesCArray* items = static_cast<CDesCArray*> (model->ItemTextArray());

	items->Reset();
	_LIT(KItemFormat, "0\tItem");
	

	for (TInt i = 0; i < 10; i++)
		{
		TBuf<32> record;
		record.Format(KItemFormat);
		items->AppendL(record);
		}

	iListBox->HandleItemAdditionL();
	

	}
