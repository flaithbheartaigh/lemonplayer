/*
* ==============================================================================
*  Name        : clientservercommon.h
*  Part of     : CSSync
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/


#ifndef __CLIENTSERVERCOMMON_H__
#define __CLIENTSERVERCOMMON_H__

// INCLUDE FILES
#include <e32base.h>

// CONSTANTS
_LIT( K$(baseName)ServerName,"$(baseName)Server" ); // Server name
_LIT( K$(baseName)ServerSemaphoreName, "$(baseName)Semaphore" );

// The server version. A version must be specified when
// creating a session with the server.
const TUint K$(baseName)ServMajorVersionNumber=0;
const TUint K$(baseName)ServMinorVersionNumber=1;
const TUint K$(baseName)ServBuildVersionNumber=1;

// DATA TYPES
// Opcodes used in message passing between client and server
enum T$(baseName)ServRqst
    {
    E$(baseName)ServRequestTime
    };

#endif // __CLIENTSERVERCOMMON_H__

// End of File
