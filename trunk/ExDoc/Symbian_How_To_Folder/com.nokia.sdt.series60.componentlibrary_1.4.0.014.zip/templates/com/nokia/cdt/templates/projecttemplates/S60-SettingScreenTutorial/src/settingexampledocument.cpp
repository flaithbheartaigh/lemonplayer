/*
 * ============================================================================
 *  Name	 : CSettingExampleDocument from SettingExampleDocument.cpp
 *  Part of  : SettingExample
 *  Created  : by $(author)
 *  Copyright: $(copyright)
 * ============================================================================
 */
#include "SettingExampleUi.h"
#include "SettingExampleDocument.h"

// implementation is purely framework code. Document class not customised
// in this application

CSettingExampleDocument* CSettingExampleDocument::NewL(CEikApplication& aApp)
	{
	CSettingExampleDocument* self = NewLC(aApp);
	CleanupStack::Pop(self);
	return self;
	}

CSettingExampleDocument* CSettingExampleDocument::NewLC(CEikApplication& aApp)
	{
	CSettingExampleDocument* self = new (ELeave) CSettingExampleDocument(aApp);
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
	}

void CSettingExampleDocument::ConstructL()
	{
	}	

CSettingExampleDocument::CSettingExampleDocument(CEikApplication& aApp) : CAknDocument(aApp) 
	{
	}   

CSettingExampleDocument::~CSettingExampleDocument()
	{
	}

CEikAppUi* CSettingExampleDocument::CreateAppUiL()
	{
	// Create the application user interface, and return a pointer to it
	CEikAppUi* appUi = new (ELeave) CSettingExampleAppUi;
	return appUi;
	}

