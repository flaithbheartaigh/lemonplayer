/*
* ==============================================================================
*  Name        : timesession.h
*  Part of     : CSSync
*  Interface   :
*  Description :
*  Version     :
*
*  Copyright (c) 2006 Nokia Corporation.
*  This material, including documentation and any related
*  computer programs, is protected by copyright controlled by
*  Nokia Corporation.
* ==============================================================================
*/


#ifndef ___$(baseNameUpper)SESSION_H__
#define ___$(baseNameUpper)SESSION_H__

// INCLUDE FILES
#include <e32base.h>

// FORWARD DECLARATIONS
class C$(baseName)Server;

// CLASS DECLARATION
/**
* C$(baseName)ServerSession.
*  An instance of class C$(baseName)ServerSession is created for each client.
*/
class C$(baseName)ServerSession : public CSession2
    {
    public: // Constructors and destructors

        /**
        * NewL.
        * Two-phased constructor.
        * @param aServer The server.
        * @return Pointer to created C$(baseName)ServerSession object.
        */
        static C$(baseName)ServerSession* NewL( C$(baseName)Server& aServer );

        /**
        * NewLC.
        * Two-phased constructor.
        * @param aServer The server.
        * @return Pointer to created C$(baseName)ServerSession object.
        */
        static C$(baseName)ServerSession* NewLC( C$(baseName)Server& aServer );

        /**
        * ~C$(baseName)ServerSession.
        * Destructor.
        */
        virtual ~C$(baseName)ServerSession();

    public: // Functions from base classes

        /**
        * From CSession, ServiceL.
        * Service request from client.
        * @param aMessage Message from client
        *                 (containing requested operation and any data).
        */
        void ServiceL( const RMessage2& aMessage );

    private: // Constructors and destructors

        /**
        * C$(baseName)ServerSession.
        * C++ default constructor.
        * @param aServer The server.
        */
        C$(baseName)ServerSession( C$(baseName)Server& aServer );

        /**
        * ConstructL.
        * 2nd phase constructor.
        */
        void ConstructL();

    private: // New methods

        /**
        * PanicClient.
        * Causes the client thread to panic.
        * @param aMessage Message from client.
        * @param aPanic Panic code.
        */
        void PanicClient( const RMessagePtr2& aMessage, TInt aPanic ) const;

        /**
        * RequestTimeL.
        * Handle the result of the client requesting the time.
        * Gets the time and writes it back to the client synchronously.
        * @param aMessage Message from client.
        */
        void RequestTimeL( const RMessage2& aMessage );

    private: // Data

        /**
        * iServer, reference to the server.
        */
        C$(baseName)Server& iServer;
    };

#endif // ___$(baseNameUpper)SESSION_H__


// End of File
