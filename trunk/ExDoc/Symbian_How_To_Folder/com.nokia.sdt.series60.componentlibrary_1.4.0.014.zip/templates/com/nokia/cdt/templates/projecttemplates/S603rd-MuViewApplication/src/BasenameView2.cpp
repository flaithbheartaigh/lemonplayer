/*
============================================================================
 Name		: $(baseName)View2.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(baseName)View2 implementation
============================================================================
*/

// INCLUDE FILES
#include  <aknviewappui.h>
#include  <avkon.hrh>
#include  <$(baseName).rsg>
#include  "$(baseName)View2.h"
#include  "$(baseName)Container2.h" 

// ================= MEMBER FUNCTIONS =======================

// ---------------------------------------------------------
// C$(baseName)View2::ConstructL(const TRect& aRect)
// EPOC two-phased constructor
// ---------------------------------------------------------
//
void C$(baseName)View2::ConstructL()
	{
	BaseConstructL( R_VIEW2 );
	}

// ---------------------------------------------------------
// C$(baseName)View2::~C$(baseName)View2()
// destructor
// ---------------------------------------------------------
//
C$(baseName)View2::~C$(baseName)View2()
	{
	if ( iContainer )
		{
		AppUi()->RemoveFromViewStack( *this, iContainer );
		}

	delete iContainer;
	}

// ---------------------------------------------------------
// TUid C$(baseName)View2::Id()
// 
// ---------------------------------------------------------
//
TUid C$(baseName)View2::Id() const
	{
	return KView2Id;
	}

// ---------------------------------------------------------
// C$(baseName)View2::HandleCommandL(TInt aCommand)
// takes care of view command handling
// ---------------------------------------------------------
//
void C$(baseName)View2::HandleCommandL(TInt aCommand)
	{   
	switch ( aCommand )
		{
		case EAknSoftkeyOk:
			{
			iEikonEnv->InfoMsg( _L("view2 ok") );
			break;
			}
		case EAknSoftkeyBack:
			{
			AppUi()->HandleCommandL(EEikCmdExit);
			break;
			}
		default:
			{
			AppUi()->HandleCommandL( aCommand );
			break;
			}
		}
	}

// ---------------------------------------------------------
// C$(baseName)View2::HandleViewRectChange()
// ---------------------------------------------------------
//
void C$(baseName)View2::HandleViewRectChange()
	{
	if ( iContainer )
		{
		iContainer->SetRect( ClientRect() );
		}
	}

// ---------------------------------------------------------
// C$(baseName)View2::DoActivateL(...)
// 
// ---------------------------------------------------------
//
void C$(baseName)View2::DoActivateL(
	const TVwsViewId& /*aPrevViewId*/,TUid /*aCustomMessageId*/,
	const TDesC8& /*aCustomMessage*/)
	{
	if (!iContainer)
		{
		iContainer = new (ELeave) C$(baseName)Container2;
		iContainer->SetMopParent(this);
		iContainer->ConstructL( ClientRect() );
		AppUi()->AddToStackL( *this, iContainer );
		}
	}

// ---------------------------------------------------------
// C$(baseName)View2::DoDeactivate()
// 
// ---------------------------------------------------------
//
void C$(baseName)View2::DoDeactivate()
	{
	if ( iContainer )
		{
		AppUi()->RemoveFromViewStack( *this, iContainer );
		}
	
	delete iContainer;
	iContainer = NULL;
	}



