/*
============================================================================
 Name		: $(classname)Container.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares container control for application.
============================================================================
*/

#ifndef $(classname$upper)CONTAINER_H
#define $(classname$upper)CONTAINER_H

// INCLUDES
#include <coecntrl.h>

// FORWARD DECLARATIONS

// CLASS DECLARATION

/**
*  C$(classname)Container  container control class.
*  
*/
class C$(classname)Container : public CCoeControl, MCoeControlObserver
{
	public: // Constructors and destructor		
		~C$(classname)Container();
		static C$(classname)Container* NewL(const TRect& aRect);
		static C$(classname)Container* NewLC(const TRect& aRect);
		
	private: // New functions
		void ConstructL(const TRect& aRect);
		C$(classname)Container();
		
    public: // Functions from base classes
		TKeyResponse  OfferKeyEventL(const TKeyEvent& aKeyEvent, TEventCode aType);
		
	private: // Functions from base classes
		void SizeChanged();
		TInt CountComponentControls() const;
		CCoeControl* ComponentControl(TInt aIndex) const;
		void Draw(const TRect& aRect) const;
		void HandleControlEventL(CCoeControl* aControl,TCoeEvent aEventType);
		
	private: //data
};

#endif


