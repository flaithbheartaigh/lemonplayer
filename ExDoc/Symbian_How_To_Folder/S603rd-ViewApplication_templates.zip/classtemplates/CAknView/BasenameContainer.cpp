/*
============================================================================
 Name		: $(classname)Container.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Container control implementation
============================================================================
*/

// INCLUDE FILES
#include "$(classname)Container.h"

// ================= MEMBER FUNCTIONS =======================

// -----------------------------------------------------------------------------
// C$(classname)AppContainer::NewL()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
C$(classname)Container* C$(classname)Container::NewL( const TRect& aRect )
{
	C$(classname)Container* self = C$(classname)Container::NewLC( aRect );
	CleanupStack::Pop( self );
	return self;
}

// -----------------------------------------------------------------------------
// C$(classname)AppContainer::NewLC()
// Two-phased constructor.
// -----------------------------------------------------------------------------
//
C$(classname)Container* C$(classname)Container::NewLC( const TRect& aRect )
{
	C$(classname)Container* self = new ( ELeave ) C$(classname)Container;
	CleanupStack::PushL( self );
	self->ConstructL( aRect );
	return self;
}

// -----------------------------------------------------------------------------
// C$(baseName)AppContainer::ConstructL()
// Symbian 2nd phase constructor can leave.
// -----------------------------------------------------------------------------
//
void C$(classname)Container::ConstructL( const TRect& aRect )
{
	// Create a window for this application view
	CreateWindowL();
	SetRect( aRect );
	ActivateL();
	
	//add your code here ...
}

// -----------------------------------------------------------------------------
// C$(classname)AppContainer::C$(baseName)AppContainer()
// C++ default constructor can NOT contain any code, that might leave.
// -----------------------------------------------------------------------------
//
C$(classname)Container::C$(classname)Container()
{
	// No implementation required
}


// -----------------------------------------------------------------------------
// C$(classname)AppContainer::~C$(baseName)AppContainer()
// Destructor.
// -----------------------------------------------------------------------------
//
C$(classname)Container::~C$(classname)Container()
{
	// No implementation required
}

// ---------------------------------------------------------
// C$(classname)Container::CountComponentControls() const
// ---------------------------------------------------------
//
TInt C$(classname)Container::CountComponentControls() const
{
	return 0; // return nbr of controls inside this container
}

// ---------------------------------------------------------
// C$(classname)Container::ComponentControl(TInt aIndex) const
// ---------------------------------------------------------
//
CCoeControl* C$(classname)Container::ComponentControl(TInt aIndex) const
{
	switch ( aIndex )
		{
		default:
			return NULL;
		}
}
	
// -----------------------------------------------------------------------------
// C$(classname)Container::Draw()
// Draws the display.
// -----------------------------------------------------------------------------
//
void C$(classname)Container::Draw( const TRect& /*aRect*/ ) const
{
	// Get the standard graphics context
	CWindowGc& gc = SystemGc();
	TRect drawRect( Rect());
	gc.Clear( drawRect );
	
	//add your code here...
}

// -----------------------------------------------------------------------------
// C$(classname)Container::SizeChanged()
// Called by framework when the view size is changed.
// -----------------------------------------------------------------------------
//
void C$(classname)Container::SizeChanged()
{  
	DrawNow();
}

// ---------------------------------------------------------
// C$(classname)Container::HandleControlEventL(
//	 CCoeControl* aControl,TCoeEvent aEventType)
// ---------------------------------------------------------
//
void C$(classname)Container::HandleControlEventL( CCoeControl* /*aControl*/,TCoeEvent /*aEventType*/)
{
	// TODO: Add your control event handler code here
}
TKeyResponse C$(classname)Container::OfferKeyEventL(const TKeyEvent& aKeyEvent,	TEventCode aType)
	{
    // See if we have a selection
    TInt code = aKeyEvent.iCode;
    switch(code)
        {
		default:
            // Let Listbox take care of its key handling           
            break;
        }	
	return EKeyWasNotConsumed;
	}
// End of File

