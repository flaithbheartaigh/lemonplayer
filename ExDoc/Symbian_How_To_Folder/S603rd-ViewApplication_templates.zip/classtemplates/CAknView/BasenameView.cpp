/*
============================================================================
 Name		: $(classname)View.cpp
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : C$(classname)View implementation
============================================================================
*/

// INCLUDE FILES
#include <aknviewappui.h>

#include "$(classname)View.h"

//copy from $(projectName)AppView.cpp
//#include "$(projectName).hrh"
//#include <$(projectName)_UID3.rsg>

// ============================ MEMBER FUNCTIONS ===============================
C$(classname)View::C$(classname)View()
{
	// No implementation required
	iContainer=NULL;
}


C$(classname)View::~C$(classname)View()
{
	DoDeactivate();
	
	//add your code here ...
	
}

C$(classname)View* C$(classname)View::NewLC()
{
	C$(classname)View* self = new (ELeave)C$(classname)View();
	CleanupStack::PushL(self);
	self->ConstructL();
	return self;
}

C$(classname)View* C$(classname)View::NewL()
{
	C$(classname)View* self=C$(classname)View::NewLC();
	CleanupStack::Pop(); // self;
	return self;
}

void C$(classname)View::ConstructL()
{
	BaseConstructL( R_VIEW_$(classname$upper) );
	
	//add your code here...
	
}
/**
 * 
 * */
TUid C$(classname)View::Id() const
{
	return TUid::Uid( E$(projectName)$(classname)ViewId );
}
void C$(classname)View::HandleCommandL( TInt aCommand )
{
	switch ( aCommand )
	{
		default:
			AppUi()->HandleCommandL(aCommand);
	}
}
void C$(classname)View::HandleStatusPaneSizeChange()
{
	if(iContainer!=NULL)
		iContainer->SetRect( ClientRect() );
}

/**
 * 
 * */
void C$(classname)View::DoActivateL(const TVwsViewId& aPrevViewId,	TUid aCustomMessageId,	const TDesC8& aCustomMessage )
{
	if( iContainer==NULL) {
		iContainer = C$(classname)Container::NewL( ClientRect() );
		iContainer->SetMopParent(this);
		AppUi()->AddToStackL( *this, iContainer );
	
		//add your init code ...
		
	}	
}
void C$(classname)View::DoDeactivate()
{
	if ( iContainer!=NULL ){
		AppUi()->RemoveFromViewStack( *this, iContainer );
		delete iContainer;
		iContainer = NULL;
	}
}
// End of File
