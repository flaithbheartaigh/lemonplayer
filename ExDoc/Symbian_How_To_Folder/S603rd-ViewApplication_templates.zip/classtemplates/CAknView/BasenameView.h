/*
============================================================================
 Name		: $(classname)View.h
 Author	  : $(author)
 Copyright   : $(copyright)
 Description : Declares view class for application.
============================================================================
*/

#ifndef $(classname$upper)VIEW_H
#define $(classname$upper)VIEW_H

// INCLUDES
#include <aknview.h>

#include "$(classname)Container.h"
// CONSTANTS

// FORWARD DECLARATIONS

// CLASS DECLARATION

/**
*  C$(classname)View view class.
* 
*/
class C$(classname)View : public CAknView
{
public: // Constructors and destructor
	~C$(classname)View();
	static C$(classname)View* NewL();
	static C$(classname)View* NewLC();
	
public:
	TUid Id() const;
	void HandleCommandL( TInt aCommand );
	void HandleStatusPaneSizeChange();
	
private:
	C$(classname)View();
	void ConstructL();
	
protected:
	void DoActivateL(const TVwsViewId& aPrevViewId,	TUid aCustomMessageId,	const TDesC8& aCustomMessage );
	void DoDeactivate();
	
private:
	C$(classname)Container * iContainer;
};

#endif


